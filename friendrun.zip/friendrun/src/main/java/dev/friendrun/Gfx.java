package dev.friendrun;

import java.lang.reflect.Method;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.item.ItemStack;

/** Всё, что рисует. Если API рисования опять поменяется — правьте только здесь. */
public final class Gfx {
    private static Method itemMethod;
    private static boolean itemSearched;

    private Gfx() {}

    public static void text(GuiGraphicsExtractor g, String s, int x, int y, int color) {
        g.text(Minecraft.getInstance().font, s, x, y, color, true);
    }

    public static void centered(GuiGraphicsExtractor g, String s, int cx, int y, int color) {
        Font f = Minecraft.getInstance().font;
        g.text(f, s, cx - f.width(s) / 2, y, color, true);
    }

    /** Рисует предмет 16x16. Метод называется item(...) или renderItem(...) — ищем по имени. */
    public static void item(GuiGraphicsExtractor g, ItemStack stack, int x, int y) {
        if (!itemSearched) {
            itemSearched = true;
            for (String n : new String[] {"item", "renderItem", "fakeItem"}) {
                try {
                    itemMethod = GuiGraphicsExtractor.class.getMethod(n, ItemStack.class, int.class, int.class);
                    break;
                } catch (NoSuchMethodException ignored) {}
            }
            if (itemMethod == null) FriendRunClient.LOG.warn("GuiGraphicsExtractor: метод рисования предмета не найден");
        }
        if (itemMethod == null) return;
        try { itemMethod.invoke(g, stack, x, y); } catch (ReflectiveOperationException e) { itemMethod = null; }
    }
}
