package dev.friendrun;

import java.lang.reflect.Method;
import java.util.concurrent.Executor;
import net.minecraft.client.Minecraft;

/**
 * Случайные усложнения раунда. Применяются ванильными командами на сервере мира, поэтому работают там,
 * где у игрока есть встроенный сервер (свой мир или мир хоста — хост применяет ко всем игрокам мира).
 */
public final class Chaos {
    public record Mod(String name, String desc, String command) {}

    public static final Mod[] MODS = {
        new Mod("Замедление", "Вы двигаетесь медленнее обычного.", "effect give @a minecraft:slowness infinite 1 true"),
        new Mod("Усталость", "Блоки ломаются гораздо дольше.", "effect give @a minecraft:mining_fatigue infinite 2 true"),
        new Mod("Постоянный голод", "Сытость быстро падает — ищите еду.", "effect give @a minecraft:hunger infinite 3 true"),
        new Mod("Тьма", "Периодически темнеет в глазах.", "effect give @a minecraft:darkness infinite 0 true"),
        new Mod("Тошнота", "Экран качается и расплывается.", "effect give @a minecraft:nausea infinite 0 true"),
        new Mod("Всего 5 сердец", "Максимум здоровья — 5 сердец.", "attribute @a minecraft:max_health base set 10"),
        new Mod("Хрупкость", "Максимум здоровья — всего 3 сердца.", "attribute @a minecraft:max_health base set 6"),
        new Mod("Свечение", "Все игроки подсвечены и видны сквозь стены.", "effect give @a minecraft:glowing infinite 0 true"),
    };
    public static final int COUNT = MODS.length;

    private static boolean active;

    private Chaos() {}

    public static String descOf(int idx) { return idx >= 0 && idx < COUNT ? MODS[idx].desc() : ""; }

    public static String nameOf(int idx) { return idx >= 0 && idx < COUNT ? MODS[idx].name() : ""; }

    /** Применить (идемпотентно — вызывается повторно, чтобы вернуть эффекты после смерти). */
    public static void apply(int idx) {
        if (idx < 0 || idx >= COUNT) return;
        active = true;
        run(MODS[idx].command());
    }

    public static void clear() {
        if (!active) return;
        active = false;
        run("effect clear @a");
        run("attribute @a minecraft:max_health base set 20");
    }

    // ---------- команда на сервере (рефлексия: сигнатуры меняются между версиями) ----------
    static void run(String cmd) {
        Object srv = Minecraft.getInstance().getSingleplayerServer();
        if (!(srv instanceof Executor ex)) return;
        ex.execute(() -> {
            try {
                Object src = call(srv, "createCommandSourceStack");
                Object quiet = call(src, "withSuppressedOutput");
                if (quiet != null) src = quiet;
                Object commands = call(srv, "getCommands");
                Object r = call(commands, "performPrefixedCommand", src, cmd);
                if (r == null && !hasMethod(commands, "performPrefixedCommand"))
                    FriendRunClient.LOG.warn("FriendRun: performPrefixedCommand не найден");
            } catch (Throwable t) {
                FriendRunClient.LOG.warn("FriendRun: команда усложнения не выполнена: " + cmd, t);
            }
        });
    }

    private static boolean hasMethod(Object o, String name) {
        for (Method m : o.getClass().getMethods()) if (m.getName().equals(name)) return true;
        return false;
    }

    private static Object call(Object o, String name, Object... args) throws Exception {
        if (o == null) return null;
        for (Method m : o.getClass().getMethods()) {
            if (!m.getName().equals(name) || m.getParameterCount() != args.length) continue;
            Class<?>[] pt = m.getParameterTypes();
            boolean ok = true;
            for (int i = 0; i < pt.length; i++) if (args[i] != null && !pt[i].isInstance(args[i])) { ok = false; break; }
            if (ok) { m.setAccessible(true); return m.invoke(o, args); }
        }
        return null;
    }
}
