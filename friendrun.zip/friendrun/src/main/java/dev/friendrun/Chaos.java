package dev.friendrun;

import java.lang.reflect.Method;
import java.util.concurrent.Executor;
import net.minecraft.client.Minecraft;

/**
 * Случайные усложнения раунда. Применяются ванильными командами на сервере мира, поэтому работают там,
 * где у игрока есть встроенный сервер (свой мир или мир хоста — хост применяет ко всем игрокам мира).
 *
 * period: 1 — состояние (эффект/атрибут), переприменяется каждые 5 секунд (возвращается после смерти);
 *         N>1 — событие, выполняется раз в N*5 секунд (но не в первую секунду раунда).
 */
public final class Chaos {
    public record Mod(String name, String desc, int period, String[] commands) {}

    private static Mod m(String name, String desc, int period, String... cmds) { return new Mod(name, desc, period, cmds); }

    public static final Mod[] MODS = {
        // --- эффекты ---
        m("Замедление", "Вы двигаетесь медленнее обычного.", 1, "effect give @a minecraft:slowness infinite 1 true"),
        m("Усталость", "Блоки ломаются гораздо дольше.", 1, "effect give @a minecraft:mining_fatigue infinite 2 true"),
        m("Постоянный голод", "Сытость быстро падает — ищите еду.", 1, "effect give @a minecraft:hunger infinite 3 true"),
        m("Тьма", "Периодически темнеет в глазах.", 1, "effect give @a minecraft:darkness infinite 0 true"),
        m("Тошнота", "Экран качается и расплывается.", 1, "effect give @a minecraft:nausea infinite 0 true"),
        m("Свечение", "Все игроки подсвечены и видны сквозь стены.", 1, "effect give @a minecraft:glowing infinite 0 true"),
        m("Слепота", "Вы почти ничего не видите и не можете бегать.", 1, "effect give @a minecraft:blindness infinite 0 true"),
        m("Вечный яд", "Здоровье падает до 1 сердца, но не ниже.", 1, "effect give @a minecraft:poison infinite 0 true"),
        m("Слабость", "Ваши удары почти не наносят урона.", 1, "effect give @a minecraft:weakness infinite 1 true"),
        m("Прыгучесть", "Вы прыгаете гораздо выше обычного.", 1, "effect give @a minecraft:jump_boost infinite 6 true"),
        m("Ускорение", "Вы бегаете очень быстро — трудно целиться.", 1, "effect give @a minecraft:speed infinite 4 true"),
        // --- здоровье и размер ---
        m("Всего 5 сердец", "Максимум здоровья — 5 сердец.", 1, "attribute @a minecraft:max_health base set 10"),
        m("Хрупкость", "Максимум здоровья — всего 3 сердца.", 1, "attribute @a minecraft:max_health base set 6"),
        m("Одно сердце", "Одна ошибка — и конец. Максимум 1 сердце.", 1, "attribute @a minecraft:max_health base set 2"),
        m("Великан", "Вы огромный: цепляетесь за всё вокруг.", 1, "attribute @a minecraft:scale base set 2.5"),
        m("Малыш", "Вы крошечный, и всё кажется огромным.", 1, "attribute @a minecraft:scale base set 0.4"),
        // --- физика ---
        m("Тяжёлая гравитация", "Вы падаете и прыгаете как в свинце.", 1, "attribute @a minecraft:gravity base set 0.2"),
        m("Лунная гравитация", "Вы парите и падаете очень медленно.", 1, "attribute @a minecraft:gravity base set 0.02"),
        m("Короткие руки", "Достаёте до блоков только вплотную.", 1, "attribute @a minecraft:block_interaction_range base set 1.5"),
        // --- мир ---
        m("Вечная ночь", "Солнце не встаёт, мобы не горят.", 1, "time set midnight"),
        m("Гроза", "Непрерывная гроза и молнии.", 1, "weather thunder 6000"),
        // --- события ---
        m("Телепорт-хаос", "Каждые 30 секунд вас бросает в другое место.", 6,
            "execute as @a at @s run spreadplayers ~ ~ 1 30 false @s"),
        m("Нашествие зомби", "Каждые 20 секунд рядом появляется зомби.", 4,
            "execute as @a at @s run summon minecraft:zombie ~2 ~ ~2"),
        m("Сюрприз: крипер", "Каждые 30 секунд рядом появляется крипер.", 6,
            "execute as @a at @s run summon minecraft:creeper ~3 ~ ~3"),
    };
    public static final int COUNT = MODS.length;

    private static boolean active;
    private static int calls;

    private Chaos() {}

    public static String descOf(int idx) { return idx >= 0 && idx < COUNT ? MODS[idx].desc() : ""; }

    public static String nameOf(int idx) { return idx >= 0 && idx < COUNT ? MODS[idx].name() : ""; }

    /** Вызывается в начале раунда и затем каждые 5 секунд. */
    public static void apply(int idx) {
        if (idx < 0 || idx >= COUNT) return;
        if (!active) { active = true; calls = 0; }
        Mod mod = MODS[idx];
        boolean now = mod.period() == 1 || (calls > 0 && calls % mod.period() == 0);
        calls++;
        if (!now) return;
        for (String c : mod.commands()) run(c);
    }

    public static void clear() {
        if (!active) return;
        active = false;
        calls = 0;
        run("effect clear @a");
        run("attribute @a minecraft:max_health base set 20");
        run("attribute @a minecraft:scale base set 1");
        run("attribute @a minecraft:gravity base set 0.08");
        run("attribute @a minecraft:block_interaction_range base set 4.5");
    }

    // ---------- команда на сервере (рефлексия: сигнатуры меняются между версиями) ----------
    static void run(String cmd) {
        Object srv = Minecraft.getInstance().getSingleplayerServer();
        if (!(srv instanceof Executor ex)) return;
        ex.execute(() -> {
            try {
                Object src = call(srv, "createCommandSourceStack");
                Object quiet = call(src, "withSuppressedOutput");
                if (quiet != null) src = quiet;
                Object commands = call(srv, "getCommands");
                Object r = call(commands, "performPrefixedCommand", src, cmd);
                if (r == null && !hasMethod(commands, "performPrefixedCommand"))
                    FriendRunClient.LOG.warn("FriendRun: performPrefixedCommand не найден");
            } catch (Throwable t) {
                FriendRunClient.LOG.warn("FriendRun: команда усложнения не выполнена: " + cmd, t);
            }
        });
    }

    private static boolean hasMethod(Object o, String name) {
        for (Method m : o.getClass().getMethods()) if (m.getName().equals(name)) return true;
        return false;
    }

    private static Object call(Object o, String name, Object... args) throws Exception {
        if (o == null) return null;
        for (Method m : o.getClass().getMethods()) {
            if (!m.getName().equals(name) || m.getParameterCount() != args.length) continue;
            Class<?>[] pt = m.getParameterTypes();
            boolean ok = true;
            for (int i = 0; i < pt.length; i++) if (args[i] != null && !pt[i].isInstance(args[i])) { ok = false; break; }
            if (ok) { m.setAccessible(true); return m.invoke(o, args); }
        }
        return null;
    }
}
