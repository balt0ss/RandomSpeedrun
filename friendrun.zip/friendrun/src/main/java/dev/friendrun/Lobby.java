package dev.friendrun;

import com.google.gson.*;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Random;
import java.util.concurrent.*;

/**
 * Лобби по названию поверх Firebase Realtime Database (REST, без аккаунтов у игроков).
 * Документ: /friendrun/<лобби>.json
 *   host, hostSeen, mode(0/1), itemSeed(str), launched, worldSeed(str), address, roundId,
 *   roundSeed(str), startAt(epoch ms), winner{name,ms,round}, players{<name>{ready,lastSeen,win{round,ms}}}
 * Хост — «арбитр»: решает, когда старт, и кто победил. Остальные только читают и пишут своё.
 */
public final class Lobby {
    public interface Listener {
        void onDoc(JsonObject doc);   // вызывается в потоке опроса!
        void onClosed(String reason);
    }

    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private static final Random RNG = new Random();

    public final String name;
    public final String me;
    public final boolean host;
    private final String base;
    private final Listener listener;
    private final ScheduledExecutorService ex = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "FriendRun-Lobby");
        t.setDaemon(true);
        return t;
    });
    private ScheduledFuture<?> poller;
    private int tick = 0;
    private int failures = 0;
    private volatile boolean closed = false;

    private Lobby(String dbUrl, String name, String me, boolean host, Listener l) {
        String u = dbUrl.trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        this.base = u + "/friendrun/" + name;
        this.name = name; this.me = me; this.host = host; this.listener = l;
    }

    public static boolean validName(String n) { return n.matches("[A-Za-z0-9_-]{1,24}"); }
    public static String newSeed() { return Long.toString(RNG.nextLong()); }


    // ---------- список открытых лобби ----------
    public record Entry(String name, String host, int players, int mode, boolean launched) {}

    public static java.util.List<Entry> list(String dbUrl) throws IOException {
        String u = dbUrl.trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        try {
            HttpResponse<String> r = HTTP.send(
                HttpRequest.newBuilder(URI.create(u + "/friendrun.json")).timeout(Duration.ofSeconds(8)).GET().build(),
                HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() == 401 || r.statusCode() == 403)
                throw new IOException("База отклонила запрос (проверьте правила Firebase)");
            if (r.statusCode() / 100 != 2) throw new IOException("HTTP " + r.statusCode());
            java.util.List<Entry> out = new java.util.ArrayList<>();
            String t = r.body();
            if (t == null || t.isBlank() || t.equals("null")) return out;
            JsonElement root = JsonParser.parseString(t);
            if (!root.isJsonObject()) return out;
            long now = System.currentTimeMillis();
            for (String name : root.getAsJsonObject().keySet()) {
                JsonObject d = obj(root.getAsJsonObject(), name);
                if (now - num(d, "hostSeen") > 20_000) continue;   // хост офлайн
                out.add(new Entry(name, str(d, "host"), obj(d, "players").size(),
                    (int) num(d, "mode"), bool(d, "launched")));
            }
            out.sort(java.util.Comparator.comparing(Entry::name));
            return out;
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            throw new IOException("прервано");
        } catch (IllegalArgumentException iae) {
            throw new IOException("Неверный URL базы данных");
        }
    }

    // ---------- создание / вход ----------
    public static Lobby create(String dbUrl, String name, String me, Listener l) throws IOException {
        Lobby lb = new Lobby(dbUrl, name, me, true, l);
        JsonElement existing = lb.request("GET", "", null);
        if (existing != null && existing.isJsonObject()) {
            long seen = num(existing.getAsJsonObject(), "hostSeen");
            if (System.currentTimeMillis() - seen < 20_000) throw new IOException("Лобби с таким названием уже существует");
        }
        JsonObject doc = new JsonObject();
        doc.addProperty("host", me);
        doc.addProperty("hostSeen", System.currentTimeMillis());
        doc.addProperty("mode", 0);
        doc.addProperty("itemSeed", newSeed());
        doc.addProperty("chaos", false);
        doc.addProperty("chaosMod", RNG.nextInt(Chaos.COUNT));
        doc.addProperty("rollAt", 0);
        doc.addProperty("chaosRollAt", 0);
        doc.addProperty("launched", false);
        doc.addProperty("worldSeed", "0");
        doc.addProperty("address", "");
        doc.addProperty("roundId", 0);
        doc.addProperty("roundSeed", "0");
        doc.addProperty("startAt", 0);
        JsonObject players = new JsonObject();
        players.add(me, player());
        doc.add("players", players);
        lb.request("PUT", "", doc.toString());
        lb.startPolling();
        return lb;
    }

    public static Lobby join(String dbUrl, String name, String me, Listener l) throws IOException {
        Lobby lb0 = new Lobby(dbUrl, name, me, false, l);
        JsonElement e = lb0.request("GET", "", null);
        if (e == null || !e.isJsonObject()) throw new IOException("Лобби не найдено");
        JsonObject doc = e.getAsJsonObject();
        if (System.currentTimeMillis() - num(doc, "hostSeen") > 20_000) throw new IOException("Лобби не найдено (хост офлайн)");
        if (bool(doc, "launched")) throw new IOException("Игра в этом лобби уже запущена");
        String nick = me;
        JsonObject players = obj(doc, "players");
        int i = 2;
        while (players.has(nick)) nick = me + i++;
        Lobby lb = new Lobby(dbUrl, name, nick, false, l);
        lb.request("PUT", "/players/" + nick, player().toString());
        lb.startPolling();
        return lb;
    }

    private static JsonObject player() {
        JsonObject p = new JsonObject();
        p.addProperty("ready", false);
        p.addProperty("lastSeen", System.currentTimeMillis());
        return p;
    }

    // ---------- действия ----------
    public void setSettings(int mode, String itemSeed, boolean roll) {
        JsonObject o = new JsonObject();
        o.addProperty("mode", mode); o.addProperty("itemSeed", itemSeed);
        if (roll) o.addProperty("rollAt", System.currentTimeMillis());
        patch("", o);
    }
    public void setChaos(boolean on) {
        JsonObject o = new JsonObject();
        o.addProperty("chaos", on);
        if (on) {
            o.addProperty("chaosMod", RNG.nextInt(Chaos.COUNT));
            o.addProperty("chaosRollAt", System.currentTimeMillis());
        }
        patch("", o);
    }
    public void rollChaos() {
        JsonObject o = new JsonObject();
        o.addProperty("chaosMod", RNG.nextInt(Chaos.COUNT));
        o.addProperty("chaosRollAt", System.currentTimeMillis());
        patch("", o);
    }
    public void launch() {
        JsonObject o = new JsonObject();
        o.addProperty("launched", true); o.addProperty("worldSeed", newSeed());
        patch("", o);
    }
    public void setAddress(String addr) { JsonObject o = new JsonObject(); o.addProperty("address", addr); patch("", o); }
    public void setReady() { JsonObject o = new JsonObject(); o.addProperty("ready", true); patch("/players/" + me, o); }
    public void reportWin(long roundId, long ms) {
        JsonObject w = new JsonObject();
        w.addProperty("round", roundId); w.addProperty("ms", ms);
        JsonObject o = new JsonObject();
        o.add("win", w);
        patch("/players/" + me, o);
    }

    private void patch(String path, JsonObject body) {
        ex.execute(() -> { try { request("PATCH", path, body.toString()); } catch (IOException e) { fail(e); } });
    }

    public void close() {
        if (closed) return;
        closed = true;
        if (poller != null) poller.cancel(false);
        ex.execute(() -> {
            try { request("DELETE", host ? "" : "/players/" + me, null); } catch (IOException ignored) {}
        });
        ex.shutdown();
    }

    // ---------- опрос ----------
    private void startPolling() {
        poller = ex.scheduleWithFixedDelay(this::poll, 0, 1000, TimeUnit.MILLISECONDS);
    }

    private void poll() {
        if (closed) return;
        try {
            JsonElement e = request("GET", "", null);
            failures = 0;
            if (e == null || !e.isJsonObject()) { shutdown("Лобби закрыто"); return; }
            JsonObject doc = e.getAsJsonObject();
            if (!host && !obj(doc, "players").has(me)) { shutdown("Вас удалили из лобби"); return; }
            if (++tick % 5 == 0) heartbeat();
            if (host) hostLogic(doc);
            listener.onDoc(doc);
        } catch (IOException ex2) {
            if (++failures >= 10) shutdown("Нет связи с базой данных");
        } catch (RuntimeException re) {
            FriendRunClient.LOG.warn("poll error", re);
        }
    }

    private void heartbeat() throws IOException {
        JsonObject o = new JsonObject();
        o.addProperty("lastSeen", System.currentTimeMillis());
        request("PATCH", "/players/" + me, o.toString());
        if (host) {
            JsonObject h = new JsonObject();
            h.addProperty("hostSeen", System.currentTimeMillis());
            request("PATCH", "", h.toString());
        }
    }

    private void hostLogic(JsonObject doc) throws IOException {
        long now = System.currentTimeMillis();
        JsonObject players = obj(doc, "players");
        JsonObject updates = new JsonObject();

        // выкинуть пропавших игроков
        for (String p : players.keySet()) {
            if (!p.equals(me) && now - num(obj(players, p), "lastSeen") > 20_000) {
                updates.add("players/" + p, JsonNull.INSTANCE);
            }
        }
        boolean launched = bool(doc, "launched");
        long startAt = num(doc, "startAt");
        long roundId = num(doc, "roundId");

        if (launched && startAt == 0 && !players.isEmpty()) {
            boolean all = true;
            for (String p : players.keySet()) if (!bool(obj(players, p), "ready")) { all = false; break; }
            if (all) {
                updates.addProperty("startAt", now + 5000);
                updates.addProperty("roundSeed", str(doc, "itemSeed"));
                updates.addProperty("roundId", roundId + 1);
                updates.addProperty("roundMod", bool(doc, "chaos") ? (int) num(doc, "chaosMod") : -1);
            }
        } else if (startAt > 0) {
            String best = null; long bestMs = Long.MAX_VALUE;
            for (String p : players.keySet()) {
                JsonObject w = obj(obj(players, p), "win");
                if (w.size() > 0 && num(w, "round") == roundId && num(w, "ms") < bestMs) { best = p; bestMs = num(w, "ms"); }
            }
            if (best != null) {
                updates.addProperty("winner/name", best);
                updates.addProperty("winner/ms", bestMs);
                updates.addProperty("winner/round", roundId);
                updates.addProperty("startAt", 0);
                updates.addProperty("itemSeed", newSeed());
                if (bool(doc, "chaos")) updates.addProperty("chaosMod", RNG.nextInt(Chaos.COUNT));
                for (String p : players.keySet()) {
                    updates.addProperty("players/" + p + "/ready", false);
                    updates.add("players/" + p + "/win", JsonNull.INSTANCE);
                }
            }
        }
        if (updates.size() > 0) request("PATCH", "", updates.toString());
    }

    private void shutdown(String reason) {
        if (closed) return;
        closed = true;
        if (poller != null) poller.cancel(false);
        ex.shutdown();
        listener.onClosed(reason);
    }

    private void fail(IOException e) { FriendRunClient.LOG.warn("lobby write failed", e); }

    // ---------- HTTP ----------
    private JsonElement request(String method, String path, String body) throws IOException {
        try {
            HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(base + path + ".json"))
                .timeout(Duration.ofSeconds(8));
            HttpRequest.BodyPublisher bp = body == null ? HttpRequest.BodyPublishers.noBody()
                : HttpRequest.BodyPublishers.ofString(body);
            HttpResponse<String> r = HTTP.send(b.method(method, bp).header("Content-Type", "application/json").build(),
                HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() == 401 || r.statusCode() == 403)
                throw new IOException("База отклонила запрос (проверьте правила Firebase, см. README)");
            if (r.statusCode() / 100 != 2) throw new IOException("HTTP " + r.statusCode());
            String t = r.body();
            if (t == null || t.isBlank() || t.equals("null")) return null;
            return JsonParser.parseString(t);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            throw new IOException("прервано");
        } catch (IllegalArgumentException iae) {
            throw new IOException("Неверный URL базы данных");
        }
    }

    // ---------- JSON-хелперы ----------
    public static JsonObject obj(JsonObject o, String k) {
        return o != null && o.has(k) && o.get(k).isJsonObject() ? o.getAsJsonObject(k) : new JsonObject();
    }
    public static String str(JsonObject o, String k) { return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : ""; }
    public static long num(JsonObject o, String k) {
        try { return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsLong() : 0; } catch (Exception e) { return 0; }
    }
    public static boolean bool(JsonObject o, String k) { return o.has(k) && !o.get(k).isJsonNull() && o.get(k).getAsBoolean(); }
}
