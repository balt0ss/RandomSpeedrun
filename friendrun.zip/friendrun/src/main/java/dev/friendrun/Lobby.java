package dev.friendrun;

import com.google.gson.*;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Random;
import java.util.concurrent.*;

/**
 * Лобби по названию поверх Firebase Realtime Database (REST, без аккаунтов у игроков).
 * Документ: /friendrun/<лобби>.json
 *   host, hostSeen, mode(0/1), itemSeed(str), launched, worldSeed(str), address, roundId,
 *   roundSeed(str), startAt(epoch ms), winner{name,ms,round}, players{<name>{ready,lastSeen,win{round,ms}}}
 * Хост — «арбитр»: решает, когда старт, и кто победил. Остальные только читают и пишут своё.
 */
public final class Lobby {
    public interface Listener {
        void onDoc(JsonObject doc);   // вызывается в потоке опроса!
        void onClosed(String reason);
    }

    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private static final Random RNG = new Random();

    public final String name;
    public final String me;
    public final boolean host;
    private final String base;
    private final Listener listener;
    private final ScheduledExecutorService ex = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "FriendRun-Lobby");
        t.setDaemon(true);
        return t;
    });
    private ScheduledFuture<?> poller;
    private long lastBeat = 0;
    private long nextDelay = 1000;
    private int failures = 0;
    private volatile boolean closed = false;

    private Lobby(String dbUrl, String name, String me, boolean host, Listener l) {
        String u = dbUrl.trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        this.base = u + "/friendrun/" + name;
        this.name = name; this.me = me; this.host = host; this.listener = l;
    }

    public static boolean validName(String n) { return n.matches("[A-Za-z0-9_-]{1,24}"); }
    public static String newSeed() { return Long.toString(RNG.nextLong()); }


    // ---------- список открытых лобби ----------
    public record Entry(String name, String host, int players, int mode, boolean launched) {}

    public static java.util.List<Entry> list(String dbUrl) throws IOException {
        String u = dbUrl.trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        try {
            HttpResponse<String> r = HTTP.send(
                HttpRequest.newBuilder(URI.create(u + "/friendrun.json")).timeout(Duration.ofSeconds(8)).GET().build(),
                HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() == 401 || r.statusCode() == 403)
                throw new IOException("База отклонила запрос (проверьте правила Firebase)");
            if (r.statusCode() / 100 != 2) throw new IOException("HTTP " + r.statusCode());
            java.util.List<Entry> out = new java.util.ArrayList<>();
            String t = r.body();
            if (t == null || t.isBlank() || t.equals("null")) return out;
            JsonElement root = JsonParser.parseString(t);
            if (!root.isJsonObject()) return out;
            long now = System.currentTimeMillis();
            for (String name : root.getAsJsonObject().keySet()) {
                JsonObject d = obj(root.getAsJsonObject(), name);
                if (now - num(d, "hostSeen") > 20_000) continue;   // хост офлайн
                out.add(new Entry(name, str(d, "host"), obj(d, "players").size(),
                    (int) num(d, "mode"), bool(d, "launched")));
            }
            out.sort(java.util.Comparator.comparing(Entry::name));
            return out;
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            throw new IOException("прервано");
        } catch (IllegalArgumentException iae) {
            throw new IOException("Неверный URL базы данных");
        }
    }

    // ---------- создание / вход ----------
    public static Lobby create(String dbUrl, String name, String me, Listener l) throws IOException {
        Lobby lb = new Lobby(dbUrl, name, me, true, l);
        JsonElement existing = lb.request("GET", "", null);
        if (existing != null && existing.isJsonObject()) {
            long seen = num(existing.getAsJsonObject(), "hostSeen");
            if (System.currentTimeMillis() - seen < 20_000) throw new IOException("Лобби с таким названием уже существует");
        }
        JsonObject doc = new JsonObject();
        doc.addProperty("host", me);
        doc.addProperty("hostSeen", System.currentTimeMillis());
        doc.addProperty("mode", 0);
        doc.addProperty("itemSeed", newSeed());
        doc.addProperty("chaos", false);
        doc.addProperty("gameMode", 0);
        doc.addProperty("convTotal", 20);
        doc.addProperty("convSlot", 3);
        doc.addProperty("chainLen", 5);
        doc.addProperty("bingoSize", 3);
        doc.addProperty("bingoFull", false);
        doc.addProperty("roundGame", 0);
        doc.addProperty("chaosMod", RNG.nextInt(Chaos.COUNT));
        doc.addProperty("rollAt", 0);
        doc.addProperty("chaosRollAt", 0);
        doc.addProperty("launched", false);
        doc.addProperty("worldSeed", "0");
        doc.addProperty("address", "");
        doc.addProperty("lanAddress", "");
        doc.addProperty("roundId", 0);
        doc.addProperty("roundSeed", "0");
        doc.addProperty("startAt", 0);
        JsonObject players = new JsonObject();
        players.add(me, player());
        doc.add("players", players);
        lb.cleanupStale(dbUrl);
        lb.request("PUT", "", doc.toString());
        lb.startPolling();
        return lb;
    }

    public static Lobby join(String dbUrl, String name, String me, Listener l) throws IOException {
        Lobby lb0 = new Lobby(dbUrl, name, me, false, l);
        JsonElement e = lb0.request("GET", "", null);
        if (e == null || !e.isJsonObject()) throw new IOException("Лобби не найдено");
        JsonObject doc = e.getAsJsonObject();
        if (System.currentTimeMillis() - num(doc, "hostSeen") > 20_000) throw new IOException("Лобби не найдено (хост офлайн)");
        if (bool(doc, "launched")) throw new IOException("Игра в этом лобби уже запущена");
        String nick = me;
        JsonObject players = obj(doc, "players");
        int i = 2;
        while (players.has(nick)) nick = me + i++;
        Lobby lb = new Lobby(dbUrl, name, nick, false, l);
        lb.request("PUT", "/players/" + nick, player().toString());
        lb.startPolling();
        return lb;
    }

    private static JsonObject player() {
        JsonObject p = new JsonObject();
        p.addProperty("ready", false);
        p.addProperty("lastSeen", System.currentTimeMillis());
        return p;
    }

    // ---------- действия ----------
    public void setSettings(int mode, String itemSeed, boolean roll) {
        JsonObject o = new JsonObject();
        o.addProperty("mode", mode); o.addProperty("itemSeed", itemSeed);
        if (roll) o.addProperty("rollAt", System.currentTimeMillis());
        patch("", o);
    }
    public static long orDef(long v, long def) { return v > 0 ? v : def; }
    public void setNum(String key, long v) { JsonObject o = new JsonObject(); o.addProperty(key, v); patch("", o); }
    public void setFlag(String key, boolean v) { JsonObject o = new JsonObject(); o.addProperty(key, v); patch("", o); }
    public void setGameMode(int g) { JsonObject o = new JsonObject(); o.addProperty("gameMode", g); patch("", o); }
    public void reportScore(long score, long ms) {
        JsonObject o = new JsonObject();
        o.addProperty("score", score); o.addProperty("lastMs", ms);
        patch("/players/" + me, o);
    }
    public void setChaos(boolean on) {
        JsonObject o = new JsonObject();
        o.addProperty("chaos", on);
        if (on) {
            o.addProperty("chaosMod", RNG.nextInt(Chaos.COUNT));
            o.addProperty("chaosRollAt", System.currentTimeMillis());
        }
        patch("", o);
    }
    public void rollChaos() {
        JsonObject o = new JsonObject();
        o.addProperty("chaosMod", RNG.nextInt(Chaos.COUNT));
        o.addProperty("chaosRollAt", System.currentTimeMillis());
        patch("", o);
    }
    public void launch() {
        JsonObject o = new JsonObject();
        o.addProperty("launched", true); o.addProperty("worldSeed", newSeed());
        patch("", o);
    }
    public void setLanAddress(String addr) { JsonObject o = new JsonObject(); o.addProperty("lanAddress", addr); patch("", o); }
    public void setAddress(String addr) { JsonObject o = new JsonObject(); o.addProperty("address", addr); patch("", o); }
    public void setReady() { JsonObject o = new JsonObject(); o.addProperty("ready", true); patch("/players/" + me, o); }
    public void reportWin(long roundId, long ms) {
        JsonObject w = new JsonObject();
        w.addProperty("round", roundId); w.addProperty("ms", ms);
        JsonObject o = new JsonObject();
        o.add("win", w);
        patch("/players/" + me, o);
    }

    private void patch(String path, JsonObject body) {
        ex.execute(() -> { try { request("PATCH", path, body.toString()); } catch (IOException e) { fail(e); } });
    }

    public void close() {
        if (closed) return;
        closed = true;
        if (poller != null) poller.cancel(false);
        ex.execute(() -> {
            try { request("DELETE", host ? "" : "/players/" + me, null); } catch (IOException ignored) {}
        });
        ex.shutdown();
    }

    // ---------- опрос ----------
    private void startPolling() { schedule(0); }

    private void schedule(long delayMs) {
        if (closed) return;
        try { poller = ex.schedule(this::pollTask, delayMs, TimeUnit.MILLISECONDS); }
        catch (RejectedExecutionException ignored) {}
    }

    private void pollTask() {
        try { poll(); } finally { schedule(nextDelay); }
    }

    private void poll() {
        if (closed) return;
        try {
            JsonElement e = request("GET", "", null);
            failures = 0;
            if (e == null || !e.isJsonObject()) { shutdown("Лобби закрыто"); return; }
            JsonObject doc = e.getAsJsonObject();
            if (!host && !obj(doc, "players").has(me)) { shutdown("Вас удалили из лобби"); return; }
            long nowMs = System.currentTimeMillis();
            if (nowMs - lastBeat > 5000) { lastBeat = nowMs; heartbeat(); }
            if (host) hostLogic(doc);
            // реже опрашиваем, пока все просто ждут /go; чаще — при настройке лобби и во время раунда
            nextDelay = (bool(doc, "launched") && num(doc, "startAt") == 0) ? 2000 : 1000;
            listener.onDoc(doc);
        } catch (IOException ex2) {
            if (++failures >= 10) shutdown("Нет связи с базой данных");
        } catch (RuntimeException re) {
            FriendRunClient.LOG.warn("poll error", re);
        }
    }

    /** Удаляет лобби, чей хост не отвечает больше минуты (вылетел, не закрыв лобби). */
    private void cleanupStale(String dbUrl) {
        try {
            String u = dbUrl.trim();
            while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
            String root = u + "/friendrun";
            JsonElement all = send("GET", root, null);
            if (all == null || !all.isJsonObject()) return;
            long now = System.currentTimeMillis();
            for (String n : all.getAsJsonObject().keySet()) {
                if (n.equals(name)) continue;
                if (now - num(obj(all.getAsJsonObject(), n), "hostSeen") > 60_000) send("DELETE", root + "/" + n, null);
            }
        } catch (IOException | RuntimeException e) {
            FriendRunClient.LOG.warn("FRun: очистка старых лобби не удалась: {}", e.toString());
        }
    }

    private void heartbeat() throws IOException {
        JsonObject o = new JsonObject();
        o.addProperty("lastSeen", System.currentTimeMillis());
        request("PATCH", "/players/" + me, o.toString());
        if (host) {
            JsonObject h = new JsonObject();
            h.addProperty("hostSeen", System.currentTimeMillis());
            request("PATCH", "", h.toString());
        }
    }

    private void hostLogic(JsonObject doc) throws IOException {
        long now = System.currentTimeMillis();
        JsonObject players = obj(doc, "players");
        JsonObject updates = new JsonObject();

        // выкинуть пропавших игроков
        for (String p : players.keySet()) {
            if (!p.equals(me) && now - num(obj(players, p), "lastSeen") > 20_000) {
                updates.add("players/" + p, JsonNull.INSTANCE);
            }
        }
        boolean launched = bool(doc, "launched");
        long startAt = num(doc, "startAt");
        long roundId = num(doc, "roundId");
        int roundGame = (int) num(doc, "roundGame");

        if (launched && startAt == 0 && !players.isEmpty()) {
            boolean all = true;
            for (String p : players.keySet()) if (!bool(obj(players, p), "ready")) { all = false; break; }
            if (all) {
                updates.addProperty("startAt", now + 5000);
                updates.addProperty("roundSeed", str(doc, "itemSeed"));
                updates.addProperty("roundId", roundId + 1);
                updates.addProperty("roundGame", (int) num(doc, "gameMode"));
                updates.addProperty("rConvTotal", orDef(num(doc, "convTotal"), 20));
                updates.addProperty("rConvSlot", orDef(num(doc, "convSlot"), 3));
                updates.addProperty("rChainLen", orDef(num(doc, "chainLen"), 5));
                updates.addProperty("rBingoSize", orDef(num(doc, "bingoSize"), 3));
                updates.addProperty("rBingoFull", bool(doc, "bingoFull"));
                updates.addProperty("roundMod", bool(doc, "chaos") ? (int) num(doc, "chaosMod") : -1);
            }
        } else if (startAt > 0) {
            if (roundGame == Game.CONVEYOR) {
                // конвейер: раунд кончается по времени, побеждает больший счёт (при равенстве — кто раньше набрал)
                if (now >= startAt + orDef(num(doc, "rConvTotal"), 20) * 60_000L + 3000) {
                    String best = null; long bestScore = 0, bestMs = Long.MAX_VALUE;
                    for (String p : players.keySet()) {
                        long sc = num(obj(players, p), "score"), ms = num(obj(players, p), "lastMs");
                        if (sc > 0 && (sc > bestScore || (sc == bestScore && ms < bestMs))) { best = p; bestScore = sc; bestMs = ms; }
                    }
                    finishRound(updates, doc, players, best == null ? "—" : best, best == null ? 0 : bestMs, bestScore, roundGame, roundId);
                }
            } else {
                // спидран / цепочка: побеждает первый (по времени у себя) закончивший
                String best = null; long bestMs = Long.MAX_VALUE;
                for (String p : players.keySet()) {
                    JsonObject w = obj(obj(players, p), "win");
                    if (w.size() > 0 && num(w, "round") == roundId && num(w, "ms") < bestMs) { best = p; bestMs = num(w, "ms"); }
                }
                if (best != null) finishRound(updates, doc, players, best, bestMs, num(obj(players, best), "score"), roundGame, roundId);
            }
        }
        if (updates.size() > 0) request("PATCH", "", updates.toString());
    }

    /** Записывает итог раунда и готовит следующий: сброс готовности, счёта, новый предмет и усложнение. */
    private void finishRound(JsonObject updates, JsonObject doc, JsonObject players, String name, long ms, long score, int mode, long roundId) {
        updates.addProperty("winner/name", name);
        updates.addProperty("winner/ms", ms);
        updates.addProperty("winner/score", score);
        updates.addProperty("winner/mode", mode);
        updates.addProperty("winner/round", roundId);
        updates.addProperty("startAt", 0);
        updates.addProperty("itemSeed", newSeed());
        if (bool(doc, "chaos")) updates.addProperty("chaosMod", RNG.nextInt(Chaos.COUNT));
        for (String p : players.keySet()) {
            updates.addProperty("players/" + p + "/ready", false);
            updates.add("players/" + p + "/win", JsonNull.INSTANCE);
            updates.add("players/" + p + "/score", JsonNull.INSTANCE);
            updates.add("players/" + p + "/lastMs", JsonNull.INSTANCE);
        }
    }

    private void shutdown(String reason) {
        if (closed) return;
        closed = true;
        if (poller != null) poller.cancel(false);
        ex.shutdown();
        listener.onClosed(reason);
    }

    private void fail(IOException e) { FriendRunClient.LOG.warn("lobby write failed", e); }

    // ---------- HTTP ----------
    private JsonElement request(String method, String path, String body) throws IOException {
        return send(method, base + path, body);
    }

    private static JsonElement send(String method, String urlBase, String body) throws IOException {
        try {
            // записи с print=silent: Firebase не присылает обратно то, что мы сами отправили
            String suffix = method.equals("GET") ? "" : "?print=silent";
            HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(urlBase + ".json" + suffix))
                .timeout(Duration.ofSeconds(8));
            HttpRequest.BodyPublisher bp = body == null ? HttpRequest.BodyPublishers.noBody()
                : HttpRequest.BodyPublishers.ofString(body);
            HttpResponse<String> r = HTTP.send(b.method(method, bp).header("Content-Type", "application/json").build(),
                HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() == 401 || r.statusCode() == 403)
                throw new IOException("База отклонила запрос (проверьте правила Firebase, см. README)");
            if (r.statusCode() / 100 != 2) throw new IOException("HTTP " + r.statusCode());
            String t = r.body();
            if (t == null || t.isBlank() || t.equals("null")) return null;
            return JsonParser.parseString(t);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            throw new IOException("прервано");
        } catch (IllegalArgumentException iae) {
            throw new IOException("Неверный URL базы данных");
        }
    }

    // ---------- JSON-хелперы ----------
    public static JsonObject obj(JsonObject o, String k) {
        return o != null && o.has(k) && o.get(k).isJsonObject() ? o.getAsJsonObject(k) : new JsonObject();
    }
    public static String str(JsonObject o, String k) { return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : ""; }
    public static long num(JsonObject o, String k) {
        try { return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsLong() : 0; } catch (Exception e) { return 0; }
    }
    public static boolean bool(JsonObject o, String k) { return o.has(k) && !o.get(k).isJsonNull() && o.get(k).getAsBoolean(); }
}
