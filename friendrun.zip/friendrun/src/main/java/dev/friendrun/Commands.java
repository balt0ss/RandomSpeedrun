package dev.friendrun;

import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;

public final class Commands {
    private Commands() {}

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommands.literal("go").executes(ctx -> { FriendRunClient.go(); return 1; }));
            dispatcher.register(ClientCommands.literal("rr")
                .then(ClientCommands.literal("leave").executes(ctx -> {
                    FriendRunClient.leave(); FriendRunClient.chat("Вы вышли из лобби."); return 1; }))
                .then(ClientCommands.literal("domain")
                    .then(ClientCommands.argument("address", com.mojang.brigadier.arguments.StringArgumentType.greedyString())
                        .executes(ctx -> {
                            FriendRunClient.setDomainManual(com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "address"));
                            return 1; })))
                .then(ClientCommands.literal("chaos")
                    .then(ClientCommands.literal("list").executes(ctx -> {
                        StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < Chaos.COUNT; i++) {
                            sb.append(i + 1).append(") ").append(Chaos.nameOf(i)).append("; ");
                            if ((i + 1) % 6 == 0 || i == Chaos.COUNT - 1) { FriendRunClient.chat(sb.toString()); sb.setLength(0); }
                        }
                        return 1; }))
                    .then(ClientCommands.literal("off").executes(ctx -> { Chaos.clear(); FriendRunClient.chat("Усложнение снято."); return 1; }))
                    .then(ClientCommands.argument("n", com.mojang.brigadier.arguments.IntegerArgumentType.integer(1, 99))
                        .executes(ctx -> { Chaos.test(com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(ctx, "n")); return 1; })))
                .then(ClientCommands.literal("status").executes(ctx -> {
                    var st = FriendRunClient.STATE;
                    FriendRunClient.chat("Фаза: " + st.phase + ", игроки: "
                        + st.playersLine());
                    return 1; })));
        });
    }
}
