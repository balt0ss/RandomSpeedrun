package dev.friendrun;

import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
// Если в 26.3 класс называется иначе (ClientCommandManager), поменяйте импорт и вызовы ClientCommands.*
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;

public final class Commands {
    private Commands() {}

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommands.literal("go").executes(ctx -> { FriendRunClient.go(); return 1; }));
            dispatcher.register(ClientCommands.literal("rr")
                .then(ClientCommands.literal("leave").executes(ctx -> {
                    FriendRunClient.leave(); FriendRunClient.chat("Вы вышли из лобби."); return 1; }))
                .then(ClientCommands.literal("status").executes(ctx -> {
                    var st = FriendRunClient.STATE;
                    FriendRunClient.chat("Фаза: " + st.phase + ", игроки: "
                        + (st.players.isEmpty() ? "-" : String.join(", ", st.players)));
                    return 1; })));
        });
    }
}
