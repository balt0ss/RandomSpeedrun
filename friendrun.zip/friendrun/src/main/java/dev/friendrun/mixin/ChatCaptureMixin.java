package dev.friendrun.mixin;

import dev.friendrun.E4mc;
import net.minecraft.client.GuiMessageTag;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MessageSignature;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Ловит ЛЮБОЕ сообщение в чат (в т.ч. клиентские от e4mc) и ищет в нём домен *.e4mc.link. */
@Mixin(ChatComponent.class)
public abstract class ChatCaptureMixin {
    @Inject(method = "addMessage(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/GuiMessageTag;)V", at = @At("HEAD"))
    private void friendrun$capture(Component message, MessageSignature sig, GuiMessageTag tag, CallbackInfo ci) {
        E4mc.scan(message.getString());
    }
}
