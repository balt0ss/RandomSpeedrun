package dev.friendrun.mixin;

import dev.friendrun.E4mc;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Ловит клиентские сообщения чата (в т.ч. от e4mc) и ищет в них домен *.e4mc.link. */
@Mixin(ChatComponent.class)
public abstract class ChatCaptureMixin {
    @Inject(method = "addMessage(Lnet/minecraft/network/chat/Component;)V", at = @At("HEAD"), require = 0)
    private void friendrun$capture(Component message, CallbackInfo ci) {
        E4mc.scan(message.getString());
    }
}
