package dev.friendrun;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;

/** Добавляет кнопку FriendRun в левый верхний угол главного меню. Если API Screens другой — правьте здесь. */
public final class TitleButton {
    private TitleButton() {}

    public static void register() {
        ScreenEvents.AFTER_INIT.register((mc, screen, w, h) -> {
            if (!(screen instanceof TitleScreen)) return;
            Button b = Button.builder(Component.literal("FriendRun"), btn -> {
                if (FriendRunClient.inLobby()) mc.setScreen(new LobbyRoomScreen(screen));
                else mc.setScreen(new LobbyMenuScreen(screen));
            }).bounds(6, 6, 90, 20).build();
            Screens.getButtons(screen).add(b);
        });
    }
}
