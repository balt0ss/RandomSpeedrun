package dev.friendrun;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;

/** config/friendrun.json: {"databaseUrl": "...", "lastLobby": "..."} */
public final class Config {
    private static final Gson GSON = new Gson();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("friendrun.json");
    public static String databaseUrl = "";
    public static String lastLobby = "";

    private Config() {}

    public static void load() {
        try {
            if (!Files.exists(FILE)) { save(); return; }
            JsonObject o = GSON.fromJson(Files.readString(FILE), JsonObject.class);
            if (o == null) return;
            if (o.has("databaseUrl")) databaseUrl = o.get("databaseUrl").getAsString();
            if (o.has("lastLobby")) lastLobby = o.get("lastLobby").getAsString();
        } catch (Exception e) {
            FriendRunClient.LOG.warn("config load failed", e);
        }
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("databaseUrl", databaseUrl);
            o.addProperty("lastLobby", lastLobby);
            Files.writeString(FILE, GSON.toJson(o));
        } catch (Exception e) {
            FriendRunClient.LOG.warn("config save failed", e);
        }
    }
}
