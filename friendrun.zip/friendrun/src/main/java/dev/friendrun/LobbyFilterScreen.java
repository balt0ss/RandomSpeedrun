package dev.friendrun;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Фильтры: какие усложнения и какие категории предметов (блоки и т.д.) могут выпасть. Меняет только хост. */
public final class LobbyFilterScreen extends Screen {
    private final Screen parent;
    private int tab = 0, page = 0;
    private int px, py, pw, ph, perPage;
    private Ui.R rBack, rTabA, rTabB, rPrev, rNext, rAll;
    private Ui.R[] rRows;
    private Button[] bRows;
    private Button[] bItemCells;
    private EditBox searchBox;
    private Button bPrev, bNext, bAll;
    private int gridCols, gridRows, gridY, gridCell;

    public LobbyFilterScreen(Screen parent) {
        super(Component.literal("FRun"));
        this.parent = parent;
    }

    private Button btn(Ui.R r, Runnable action) {
        Button b = addRenderableWidget(Button.builder(Component.empty(), x -> action.run())
            .bounds(r.x(), r.y(), r.w(), r.h()).build());
        Ui.invisible(b);
        return b;
    }

    private List<Item> filteredItems() {
        String q = searchBox == null ? "" : searchBox.getValue().trim().toLowerCase(Locale.ROOT);
        List<Item> all = ItemPicker.selectableItems();
        if (q.isEmpty()) return all;
        List<Item> out = new ArrayList<>();
        for (Item item : all) {
            String id = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(item).getPath().replace('_', ' ');
            String localized = new ItemStack(item).getHoverName().getString().toLowerCase(Locale.ROOT);
            if (id.contains(q) || localized.contains(q)) out.add(item);
        }
        return out;
    }
    private int total() { return tab == 0 ? Chaos.COUNT : tab == 1 ? ItemPicker.CAT_COUNT : filteredItems().size(); }
    private int pageCapacity() { return tab == 2 ? gridCols * gridRows : perPage; }
    private int pages() { return Math.max(1, (total() + pageCapacity() - 1) / pageCapacity()); }

    @Override
    protected void init() {
        pw = Math.min(width - 16, 460);
        px = (width - pw) / 2;
        perPage = Math.max(3, Math.min(8, (height - 150) / 22));
        gridCell = 28;
        gridCols = Math.max(4, Math.min(14, (pw - 24) / gridCell));
        gridRows = Math.max(2, Math.min(7, (height - 150) / gridCell));
        ph = 56 + perPage * 22 + 34;
        py = Math.max(4, (height - ph) / 2);
        int ix = px + 10, bw = pw - 20, third = (bw - 8) / 3;

        rBack = new Ui.R(px + pw - 10 - 64, py + 6, 64, 18);
        rTabA = new Ui.R(ix, py + 28, third, 20);
        rTabB = new Ui.R(ix + third + 4, py + 28, third, 20);
        Ui.R rTabC = new Ui.R(ix + (third + 4) * 2, py + 28, bw - (third + 4) * 2, 20);
        rRows = new Ui.R[perPage];
        bRows = new Button[perPage];
        for (int i = 0; i < perPage; i++) {
            final int idx = i;
            rRows[i] = new Ui.R(ix, py + 52 + i * 22, bw, 20);
            bRows[i] = btn(rRows[i], () -> toggle(page * perPage + idx));
        }

        // Поиск и сетка иконок используются только во вкладке «По предметам».
        searchBox = new EditBox(font, ix + 2, py + 53, bw - 4, 18, Component.literal("Поиск предмета"));
        searchBox.setHint(Component.literal("Поиск: алмаз, diamond, железо…"));
        searchBox.setMaxLength(64);
        Ui.noBorder(searchBox);
        addRenderableWidget(searchBox);
        gridY = py + 76;
        int cellCount = gridCols * gridRows;
        bItemCells = new Button[cellCount];
        for (int i = 0; i < cellCount; i++) {
            final int cell = i;
            int x = ix + (i % gridCols) * gridCell;
            int y = gridY + (i / gridCols) * gridCell;
            bItemCells[i] = btn(new Ui.R(x, y, gridCell - 2, gridCell - 2), () -> toggle(page * pageCapacity() + cell));
        }

        int ny = py + 52 + perPage * 22 + 4;
        rPrev = new Ui.R(ix, ny, 36, 20);
        rNext = new Ui.R(ix + 40, ny, 36, 20);
        rAll = new Ui.R(ix + bw - 120, ny, 120, 20);

        btn(rBack, this::onClose);
        btn(rTabA, () -> { tab = 0; page = 0; searchBox.setVisible(false); });
        btn(rTabB, () -> { tab = 1; page = 0; searchBox.setVisible(false); });
        btn(rTabC, () -> { tab = 2; page = 0; searchBox.setVisible(true); });
        bPrev = btn(rPrev, () -> { if (page > 0) page--; });
        bNext = btn(rNext, () -> { if (page < pages() - 1) page++; });
        bAll = btn(rAll, () -> FriendRunClient.enableAllFilters(tab));
        searchBox.setVisible(false);
        for (Button b : bItemCells) b.visible = false;
    }

    private void toggle(int i) {
        if (tab == 2) {
            List<Item> items = filteredItems();
            if (i < 0 || i >= items.size()) return;
            String id = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(items.get(i)).getPath();
            FriendRunClient.toggleSpecificItem(id);
        } else if (i >= 0 && i < total()) {
            if (tab == 0) FriendRunClient.toggleChaosEnabled(i);
            else FriendRunClient.toggleItemCat(i);
        }
    }

    @Override
    public void onClose() { Mc.setScreen(parent); }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        if (!FriendRunClient.inLobby()) { Mc.setScreen(parent); return; }
        RunState s = FriendRunClient.STATE;
        boolean host = s.amHost;
        if (page >= pages()) page = pages() - 1;
        boolean itemTab = tab == 2;
        searchBox.setVisible(itemTab);
        for (int i = 0; i < perPage; i++) {
            bRows[i].visible = !itemTab && page * perPage + i < total();
            bRows[i].active = host;
        }
        List<Item> items = itemTab ? filteredItems() : List.of();
        for (int i = 0; i < bItemCells.length; i++) {
            int idx = page * pageCapacity() + i;
            bItemCells[i].visible = itemTab && idx < items.size();
            bItemCells[i].active = host && bItemCells[i].visible;
        }
        bPrev.active = page > 0;
        bNext.active = page < pages() - 1;

        int panelH = itemTab ? Math.min(height - py - 4, 112 + gridRows * gridCell + 28) : ph;
        int panelY = py;
        // Сетка поиска привязана к панели, поэтому при переключении вкладки сдвигаем её и поиск.
        if (itemTab) {
            int searchY = panelY + 53;
            searchBox.setY(searchY);
            gridY = panelY + 76;
            for (int i = 0; i < bItemCells.length; i++) {
                int x = px + 10 + (i % gridCols) * gridCell;
                int y = gridY + (i / gridCols) * gridCell;
                bItemCells[i].setX(x); bItemCells[i].setY(y);
            }
        }
        int ny = itemTab ? panelY + panelH - 25 : py + 52 + perPage * 22 + 4;
        rPrev = new Ui.R(px + 10, ny, 36, 20);
        rNext = new Ui.R(px + 50, ny, 36, 20);
        rAll = new Ui.R(px + pw - 10 - 120, ny, 120, 20);
        bPrev.setX(rPrev.x()); bPrev.setY(rPrev.y());
        bNext.setX(rNext.x()); bNext.setY(rNext.y());
        bAll.setX(rAll.x()); bAll.setY(rAll.y());

        Ui.panel(g, px, panelY, pw, panelH);
        if (itemTab) Ui.frame(g, px + 10, panelY + 52, pw - 20, 20, Ui.SECTION, Ui.LINE);
        Icons.draw(g, Icons.GEAR, px + 12, panelY + 9, 1, Ui.GOLD);
        Ui.bold(g, "Фильтры", px + 24, panelY + 8, Ui.GOLD);
        Gfx.text(g, host ? (itemTab ? "поиск и выбор по иконкам" : "нажмите, чтобы включить/выключить") : "меняет только хост", px + 24 + Ui.w("Фильтры") + 8, panelY + 8, Ui.MUTED);

        super.extractRenderState(g, mx, my, delta);

        Ui.button(g, rBack, rBack.in(mx, my), true, Ui.Kind.NORMAL);
        Gfx.centered(g, "Назад", rBack.x() + rBack.w() / 2, rBack.y() + 5, Ui.TEXT);
        Ui.button(g, rTabA, rTabA.in(mx, my), true, tab == 0 ? Ui.Kind.GOLD : Ui.Kind.NORMAL);
        Gfx.centered(g, "Усложнения", rTabA.x() + rTabA.w() / 2, rTabA.cy() - 4, tab == 0 ? 0xFF1A1200 : Ui.TEXT);
        Ui.button(g, rTabB, rTabB.in(mx, my), true, tab == 1 ? Ui.Kind.GOLD : Ui.Kind.NORMAL);
        Gfx.centered(g, "Категории", rTabB.x() + rTabB.w() / 2, rTabB.cy() - 4, tab == 1 ? 0xFF1A1200 : Ui.TEXT);
        int tabX = px + 10, tabW = pw - 20;
        Ui.R rTabC = new Ui.R(rTabB.x() + rTabB.w() + 4, rTabB.y(), tabX + tabW - (rTabB.x() + rTabB.w() + 4), 20);
        Ui.button(g, rTabC, rTabC.in(mx, my), true, tab == 2 ? Ui.Kind.GOLD : Ui.Kind.NORMAL);
        Gfx.centered(g, "По предметам", rTabC.x() + rTabC.w() / 2, rTabC.cy() - 4, tab == 2 ? 0xFF1A1200 : Ui.TEXT);

        if (itemTab) {
            String query = searchBox.getValue().trim();
            Gfx.text(g, items.size() + " предметов" + (query.isEmpty() ? "" : " найдено"), px + 12, panelY + 74, Ui.MUTED);
            for (int i = 0; i < bItemCells.length; i++) {
                int idx = page * pageCapacity() + i;
                if (idx >= items.size()) continue;
                Item item = items.get(idx);
                String id = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(item).getPath();
                boolean on = !java.util.Arrays.asList(s.itemIdsOff.split(",")).contains(id);
                Button b = bItemCells[i];
                Ui.R r = new Ui.R(b.getX(), b.getY(), b.getWidth(), b.getHeight());
                boolean hover = r.in(mx, my) && host;
                Ui.button(g, r, hover, host, on ? Ui.Kind.GREEN : Ui.Kind.NORMAL);
                Gfx.item(g, new ItemStack(item), r.x() + 4, r.y() + 3);
                if (!on) {
                    Gfx.rect(g, r.x() + r.w() - 8, r.y() + r.h() - 7, r.x() + r.w() - 2, r.y() + r.h() - 2, Ui.RED);
                }
                if (hover) {
                    String label = new ItemStack(item).getHoverName().getString();
                    int tw = Math.min(width - 12, Ui.w(label) + 12);
                    int tx = Math.max(6, Math.min(width - tw - 6, mx - tw / 2));
                    int ty = Math.max(4, r.y() - 23);
                    Gfx.rect(g, tx, ty, tx + tw, ty + 18, 0xF0141917);
                    Ui.frame(g, tx, ty, tw, 18, 0xF0141917, Ui.GREEN);
                    Gfx.text(g, Ui.clip(label, tw - 10), tx + 5, ty + 5, Ui.TEXT);
                }
            }
            if (items.isEmpty()) Gfx.centered(g, "Ничего не найдено — попробуйте другое название", px + pw / 2, gridY + 10, Ui.MUTED);
        } else {
            for (int i = 0; i < perPage; i++) {
                int idx = page * perPage + i;
                if (idx >= total()) continue;
                Ui.R r = rRows[i];
                boolean on;
                String name, desc;
                if (tab == 0) { on = ((s.chaosOff >> idx) & 1) == 0; name = Chaos.nameOf(idx); desc = Chaos.descOf(idx); }
                else { on = ((s.itemOff >> idx) & 1) == 0; name = ItemPicker.CAT_NAMES[idx]; desc = ItemPicker.CAT_DESC[idx]; }
                Ui.button(g, r, r.in(mx, my) && host, host, on ? Ui.Kind.GREEN : Ui.Kind.NORMAL);
                Ui.frame(g, r.x() + 6, r.cy() - 6, 12, 12, on ? Ui.GREEN_BG : Ui.SECTION, on ? Ui.GREEN : Ui.LINE);
                if (on) Icons.draw(g, Icons.CHECK, r.x() + 8, r.cy() - 3, 1, Ui.GREEN);
                Gfx.text(g, name, r.x() + 24, r.cy() - 4, on ? Ui.TEXT : Ui.MUTED);
                int dx = r.x() + 24 + Ui.w(name) + 8;
                Gfx.text(g, Ui.clip(desc, r.x() + r.w() - 8 - dx), dx, r.cy() - 4, Ui.MUTED);
            }
        }

        Ui.button(g, rPrev, rPrev.in(mx, my), page > 0, Ui.Kind.NORMAL);
        Icons.draw(g, Icons.CHEV_L, rPrev.x() + 16, rPrev.cy() - 3, 1, page > 0 ? Ui.TEXT : Ui.MUTED);
        Ui.button(g, rNext, rNext.in(mx, my), page < pages() - 1, Ui.Kind.NORMAL);
        Icons.draw(g, Icons.CHEV_R, rNext.x() + 16, rNext.cy() - 3, 1, page < pages() - 1 ? Ui.TEXT : Ui.MUTED);
        Gfx.text(g, "Стр. " + (page + 1) + "/" + pages(), rNext.x() + rNext.w() + 10, rNext.cy() - 4, Ui.MUTED);
        Ui.button(g, rAll, rAll.in(mx, my) && host, host, Ui.Kind.NORMAL);
        Gfx.centered(g, "Включить все", rAll.x() + rAll.w() / 2, rAll.cy() - 4, host ? Ui.TEXT : Ui.MUTED);
    }
}
