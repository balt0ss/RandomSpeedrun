package dev.friendrun;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Фильтры: какие усложнения и какие категории предметов (блоки и т.д.) могут выпасть. Меняет только хост. */
public final class LobbyFilterScreen extends Screen {
    private final Screen parent;
    private int tab = 0, page = 0;
    private int px, py, pw, ph, perPage;
    private Ui.R rBack, rTabA, rTabB, rPrev, rNext, rAll;
    private Ui.R[] rRows;
    private Button[] bRows;
    private Button bPrev, bNext;

    public LobbyFilterScreen(Screen parent) {
        super(Component.literal("FRun"));
        this.parent = parent;
    }

    private Button btn(Ui.R r, Runnable action) {
        Button b = addRenderableWidget(Button.builder(Component.empty(), x -> action.run())
            .bounds(r.x(), r.y(), r.w(), r.h()).build());
        Ui.invisible(b);
        return b;
    }

    private int total() { return tab == 0 ? Chaos.COUNT : ItemPicker.CAT_COUNT; }
    private int pages() { return Math.max(1, (total() + perPage - 1) / perPage); }

    @Override
    protected void init() {
        pw = Math.min(width - 16, 420);
        px = (width - pw) / 2;
        perPage = Math.max(3, Math.min(8, (height - 150) / 22));
        ph = 56 + perPage * 22 + 34;
        py = Math.max(4, (height - ph) / 2);
        int ix = px + 10, bw = pw - 20, half = (bw - 4) / 2;

        rBack = new Ui.R(px + pw - 10 - 64, py + 6, 64, 18);
        rTabA = new Ui.R(ix, py + 28, half, 20);
        rTabB = new Ui.R(ix + half + 4, py + 28, half, 20);
        rRows = new Ui.R[perPage];
        bRows = new Button[perPage];
        for (int i = 0; i < perPage; i++) {
            final int idx = i;
            rRows[i] = new Ui.R(ix, py + 52 + i * 22, bw, 20);
            bRows[i] = btn(rRows[i], () -> toggle(page * perPage + idx));
        }
        int ny = py + 52 + perPage * 22 + 4;
        rPrev = new Ui.R(ix, ny, 36, 20);
        rNext = new Ui.R(ix + 40, ny, 36, 20);
        rAll = new Ui.R(ix + bw - 120, ny, 120, 20);

        btn(rBack, this::onClose);
        btn(rTabA, () -> { tab = 0; page = 0; });
        btn(rTabB, () -> { tab = 1; page = 0; });
        bPrev = btn(rPrev, () -> { if (page > 0) page--; });
        bNext = btn(rNext, () -> { if (page < pages() - 1) page++; });
        btn(rAll, () -> FriendRunClient.enableAllFilters(tab));
    }

    private void toggle(int i) {
        if (i < 0 || i >= total()) return;
        if (tab == 0) FriendRunClient.toggleChaosEnabled(i);
        else FriendRunClient.toggleItemCat(i);
    }

    @Override
    public void onClose() { Mc.setScreen(parent); }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        if (!FriendRunClient.inLobby()) { Mc.setScreen(parent); return; }
        RunState s = FriendRunClient.STATE;
        boolean host = s.amHost;
        if (page >= pages()) page = pages() - 1;

        for (int i = 0; i < perPage; i++) {
            bRows[i].visible = page * perPage + i < total();
            bRows[i].active = host;
        }
        bPrev.active = page > 0;
        bNext.active = page < pages() - 1;

        Ui.panel(g, px, py, pw, ph);
        Icons.draw(g, Icons.GEAR, px + 12, py + 9, 1, Ui.GOLD);
        Ui.bold(g, "Настройка раунда", px + 24, py + 8, Ui.GOLD);
        String hint = host ? "Нажмите на пункт, чтобы переключить" : "Изменять настройки может только хост";
        Gfx.text(g, hint, px + 24 + Ui.w("Настройка раунда") + 8, py + 8, Ui.MUTED);

        super.extractRenderState(g, mx, my, delta);

        Ui.button(g, rBack, rBack.in(mx, my), true, Ui.Kind.NORMAL);
        Gfx.centered(g, "Назад", rBack.x() + rBack.w() / 2, rBack.y() + 5, Ui.TEXT);

        Ui.button(g, rTabA, rTabA.in(mx, my), true, tab == 0 ? Ui.Kind.GOLD : Ui.Kind.NORMAL);
        int chaosEnabled = 0;
        for (int i = 0; i < Chaos.COUNT; i++) if (((s.chaosOff >> i) & 1) == 0) chaosEnabled++;
        Gfx.centered(g, "Усложнения  " + chaosEnabled + "/" + Chaos.COUNT, rTabA.x() + rTabA.w() / 2, rTabA.cy() - 4, tab == 0 ? 0xFF1A1200 : Ui.TEXT);
        Ui.button(g, rTabB, rTabB.in(mx, my), true, tab == 1 ? Ui.Kind.GOLD : Ui.Kind.NORMAL);
        int itemEnabled = 0;
        for (int i = 0; i < ItemPicker.CAT_COUNT; i++) if (((s.itemOff >> i) & 1) == 0) itemEnabled++;
        Gfx.centered(g, "Категории предметов  " + itemEnabled + "/" + ItemPicker.CAT_COUNT, rTabB.x() + rTabB.w() / 2, rTabB.cy() - 4, tab == 1 ? 0xFF1A1200 : Ui.TEXT);

        for (int i = 0; i < perPage; i++) {
            int idx = page * perPage + i;
            if (idx >= total()) continue;
            Ui.R r = rRows[i];
            boolean on = tab == 0 ? ((s.chaosOff >> idx) & 1) == 0 : ((s.itemOff >> idx) & 1) == 0;
            String name = tab == 0 ? Chaos.nameOf(idx) : ItemPicker.CAT_NAMES[idx];
            String desc = tab == 0 ? Chaos.descOf(idx) : ItemPicker.CAT_DESC[idx];

            Ui.button(g, r, r.in(mx, my) && host, host, on ? Ui.Kind.GREEN : Ui.Kind.NORMAL);
            Ui.frame(g, r.x() + 6, r.cy() - 6, 12, 12, on ? Ui.GREEN_BG : Ui.SECTION, on ? Ui.GREEN : Ui.LINE);
            if (on) Icons.draw(g, Icons.CHECK, r.x() + 8, r.cy() - 3, 1, Ui.GREEN);
            Gfx.text(g, name, r.x() + 24, r.cy() - 4, on ? Ui.TEXT : Ui.MUTED);
            int dx = r.x() + 24 + Ui.w(name) + 8;
            Gfx.text(g, Ui.clip(desc, r.x() + r.w() - 8 - dx), dx, r.cy() - 4, Ui.MUTED);
        }

        Ui.button(g, rPrev, rPrev.in(mx, my), page > 0, Ui.Kind.NORMAL);
        Icons.draw(g, Icons.CHEV_L, rPrev.x() + 16, rPrev.cy() - 3, 1, page > 0 ? Ui.TEXT : Ui.MUTED);
        Ui.button(g, rNext, rNext.in(mx, my), page < pages() - 1, Ui.Kind.NORMAL);
        Icons.draw(g, Icons.CHEV_R, rNext.x() + 16, rNext.cy() - 3, 1, page < pages() - 1 ? Ui.TEXT : Ui.MUTED);
        Gfx.text(g, "Стр. " + (page + 1) + "/" + pages(), rNext.x() + rNext.w() + 10, rNext.cy() - 4, Ui.MUTED);

        Ui.button(g, rAll, rAll.in(mx, my) && host, host, Ui.Kind.NORMAL);
        Gfx.centered(g, "Включить всё", rAll.x() + rAll.w() / 2, rAll.cy() - 4, host ? Ui.TEXT : Ui.MUTED);
    }
}
