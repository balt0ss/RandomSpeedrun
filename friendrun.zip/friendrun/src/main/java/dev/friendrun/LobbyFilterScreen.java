package dev.friendrun;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Фильтры: какие усложнения и какие категории предметов (блоки и т.д.) могут выпасть. Меняет только хост. */
public final class LobbyFilterScreen extends Screen {
    private final Screen parent;
    private int tab = 0, page = 0;
    private int px, py, pw, ph, perPage;
    private Ui.R rBack, rTabA, rTabB, rPrev, rNext, rAll;
    private Ui.R[] rRows;
    private Button[] bRows;
    private Button bPrev, bNext;

    public LobbyFilterScreen(Screen parent) {
        super(Component.literal("FRun"));
        this.parent = parent;
    }

    private Button btn(Ui.R r, Runnable action) {
        Button b = addRenderableWidget(Button.builder(Component.empty(), x -> action.run())
            .bounds(r.x(), r.y(), r.w(), r.h()).build());
        Ui.invisible(b);
        return b;
    }

    private int total() { return tab == 0 ? Chaos.COUNT : tab == 1 ? ItemPicker.CAT_COUNT : ItemPicker.selectableItems().size(); }
    private int pages() { return Math.max(1, (total() + perPage - 1) / perPage); }

    @Override
    protected void init() {
        pw = Math.min(width - 16, 420);
        px = (width - pw) / 2;
        perPage = Math.max(3, Math.min(8, (height - 150) / 22));
        ph = 56 + perPage * 22 + 34;
        py = Math.max(4, (height - ph) / 2);
        int ix = px + 10, bw = pw - 20, third = (bw - 8) / 3;

        rBack = new Ui.R(px + pw - 10 - 64, py + 6, 64, 18);
        rTabA = new Ui.R(ix, py + 28, third, 20);
        rTabB = new Ui.R(ix + third + 4, py + 28, third, 20);
        Ui.R rTabC = new Ui.R(ix + (third + 4) * 2, py + 28, bw - (third + 4) * 2, 20);
        rRows = new Ui.R[perPage];
        bRows = new Button[perPage];
        for (int i = 0; i < perPage; i++) {
            final int idx = i;
            rRows[i] = new Ui.R(ix, py + 52 + i * 22, bw, 20);
            bRows[i] = btn(rRows[i], () -> toggle(page * perPage + idx));
        }
        int ny = py + 52 + perPage * 22 + 4;
        rPrev = new Ui.R(ix, ny, 36, 20);
        rNext = new Ui.R(ix + 40, ny, 36, 20);
        rAll = new Ui.R(ix + bw - 120, ny, 120, 20);

        btn(rBack, this::onClose);
        btn(rTabA, () -> { tab = 0; page = 0; });
        btn(rTabB, () -> { tab = 1; page = 0; });
        btn(rTabC, () -> { tab = 2; page = 0; });
        bPrev = btn(rPrev, () -> { if (page > 0) page--; });
        bNext = btn(rNext, () -> { if (page < pages() - 1) page++; });
        btn(rAll, () -> FriendRunClient.enableAllFilters(tab));
    }

    private void toggle(int i) {
        if (i < 0 || i >= total()) return;
        if (tab == 0) FriendRunClient.toggleChaosEnabled(i);
        else if (tab == 1) FriendRunClient.toggleItemCat(i);
        else {
            if (i >= 0 && i < ItemPicker.selectableItems().size()) {
                String id = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(ItemPicker.selectableItems().get(i)).getPath();
                FriendRunClient.toggleSpecificItem(id);
            }
        }
    }

    @Override
    public void onClose() { Mc.setScreen(parent); }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        if (!FriendRunClient.inLobby()) { Mc.setScreen(parent); return; }
        RunState s = FriendRunClient.STATE;
        boolean host = s.amHost;
        if (page >= pages()) page = pages() - 1;

        for (int i = 0; i < perPage; i++) {
            bRows[i].visible = page * perPage + i < total();
            bRows[i].active = host;
        }
        bPrev.active = page > 0;
        bNext.active = page < pages() - 1;

        Ui.panel(g, px, py, pw, ph);
        Icons.draw(g, Icons.GEAR, px + 12, py + 9, 1, Ui.GOLD);
        Ui.bold(g, "Фильтры", px + 24, py + 8, Ui.GOLD);
        Gfx.text(g, host ? (tab == 2 ? "отдельные предметы" : "нажмите, чтобы включить/выключить") : "меняет только хост", px + 24 + Ui.w("Фильтры") + 8, py + 8, Ui.MUTED);

        super.extractRenderState(g, mx, my, delta);

        Ui.button(g, rBack, rBack.in(mx, my), true, Ui.Kind.NORMAL);
        Gfx.centered(g, "Назад", rBack.x() + rBack.w() / 2, rBack.y() + 5, Ui.TEXT);

        Ui.button(g, rTabA, rTabA.in(mx, my), true, tab == 0 ? Ui.Kind.GOLD : Ui.Kind.NORMAL);
        Gfx.centered(g, "Усложнения", rTabA.x() + rTabA.w() / 2, rTabA.cy() - 4, tab == 0 ? 0xFF1A1200 : Ui.TEXT);
        Ui.button(g, rTabB, rTabB.in(mx, my), true, tab == 1 ? Ui.Kind.GOLD : Ui.Kind.NORMAL);
        Gfx.centered(g, "Категории", rTabB.x() + rTabB.w() / 2, rTabB.cy() - 4, tab == 1 ? 0xFF1A1200 : Ui.TEXT);
        int tabX = px + 10, tabW = pw - 20;
        Ui.R rTabC = new Ui.R(rTabB.x() + rTabB.w() + 4, rTabB.y(), tabX + tabW - (rTabB.x() + rTabB.w() + 4), 20);
        Ui.button(g, rTabC, rTabC.in(mx, my), true, tab == 2 ? Ui.Kind.GOLD : Ui.Kind.NORMAL);
        Gfx.centered(g, "По предметам", rTabC.x() + rTabC.w() / 2, rTabC.cy() - 4, tab == 2 ? 0xFF1A1200 : Ui.TEXT);

        for (int i = 0; i < perPage; i++) {
            int idx = page * perPage + i;
            if (idx >= total()) continue;
            Ui.R r = rRows[i];
            boolean on;
            String name, desc;
            if (tab == 0) {
                on = ((s.chaosOff >> idx) & 1) == 0;
                name = Chaos.nameOf(idx); desc = Chaos.descOf(idx);
            } else if (tab == 1) {
                on = ((s.itemOff >> idx) & 1) == 0;
                name = ItemPicker.CAT_NAMES[idx]; desc = ItemPicker.CAT_DESC[idx];
            } else {
                net.minecraft.world.item.Item item = ItemPicker.selectableItems().get(idx);
                String id = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(item).getPath();
                on = !s.itemIdsOff.contains(id + ",") && !java.util.Arrays.asList(s.itemIdsOff.split(",")).contains(id);
                name = id.replace('_', ' '); desc = "minecraft:" + id;
            }

            Ui.button(g, r, r.in(mx, my) && host, host, on ? Ui.Kind.GREEN : Ui.Kind.NORMAL);
            Ui.frame(g, r.x() + 6, r.cy() - 6, 12, 12, on ? Ui.GREEN_BG : Ui.SECTION, on ? Ui.GREEN : Ui.LINE);
            if (on) Icons.draw(g, Icons.CHECK, r.x() + 8, r.cy() - 3, 1, Ui.GREEN);
            Gfx.text(g, name, r.x() + 24, r.cy() - 4, on ? Ui.TEXT : Ui.MUTED);
            int dx = r.x() + 24 + Ui.w(name) + 8;
            Gfx.text(g, Ui.clip(desc, r.x() + r.w() - 8 - dx), dx, r.cy() - 4, Ui.MUTED);
        }

        Ui.button(g, rPrev, rPrev.in(mx, my), page > 0, Ui.Kind.NORMAL);
        Icons.draw(g, Icons.CHEV_L, rPrev.x() + 16, rPrev.cy() - 3, 1, page > 0 ? Ui.TEXT : Ui.MUTED);
        Ui.button(g, rNext, rNext.in(mx, my), page < pages() - 1, Ui.Kind.NORMAL);
        Icons.draw(g, Icons.CHEV_R, rNext.x() + 16, rNext.cy() - 3, 1, page < pages() - 1 ? Ui.TEXT : Ui.MUTED);
        Gfx.text(g, "Стр. " + (page + 1) + "/" + pages(), rNext.x() + rNext.w() + 10, rNext.cy() - 4, Ui.MUTED);

        Ui.button(g, rAll, rAll.in(mx, my) && host, host, Ui.Kind.NORMAL);
        Gfx.centered(g, "Включить все", rAll.x() + rAll.w() / 2, rAll.cy() - 4, host ? Ui.TEXT : Ui.MUTED);
    }
}
