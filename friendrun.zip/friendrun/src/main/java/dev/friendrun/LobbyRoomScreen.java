package dev.friendrun;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;

public final class LobbyRoomScreen extends Screen {
    private final Screen parent;
    private Button modeBtn, rollBtn, rollChaosBtn, chaosBtn, startBtn;

    public LobbyRoomScreen(Screen parent) {
        super(Component.literal("FriendRun"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = width / 2, by = height - 124;
        RunState s = FriendRunClient.STATE;

        modeBtn = addRenderableWidget(Button.builder(Component.empty(), b ->
            FriendRunClient.setMode(s.mode == RunState.Mode.SEPARATE_WORLDS
                ? RunState.Mode.HOST_WORLD : RunState.Mode.SEPARATE_WORLDS))
            .bounds(cx - 120, by, 240, 20).build());

        rollBtn = addRenderableWidget(Button.builder(Component.literal("Ролл предмета"), b ->
            FriendRunClient.rollItem()).bounds(cx - 120, by + 24, 118, 20).build());

        rollChaosBtn = addRenderableWidget(Button.builder(Component.literal("Ролл усложнения"), b ->
            FriendRunClient.rollChaos()).bounds(cx + 2, by + 24, 118, 20).build());

        chaosBtn = addRenderableWidget(Button.builder(Component.empty(), b ->
            FriendRunClient.toggleChaos()).bounds(cx - 120, by + 48, 240, 20).build());

        startBtn = addRenderableWidget(Button.builder(Component.literal("Старт (создать мир)"), b ->
            FriendRunClient.launch()).bounds(cx - 120, by + 72, 240, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Выйти из лобби"), b -> {
            FriendRunClient.leave();
            Mc.setScreen(parent);
        }).bounds(cx - 120, by + 96, 240, 20).build());
    }

    @Override
    public void onClose() { Mc.setScreen(parent); }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        RunState s = FriendRunClient.STATE;

        // лобби закрылось (хост вышел / обрыв) — вернуться в меню
        if (!FriendRunClient.inLobby()) { Mc.setScreen(parent); return; }

        boolean host = s.amHost, open = host && !s.launched;
        modeBtn.active = open;
        rollBtn.active = open && !Roulette.running();
        rollChaosBtn.active = host && s.chaos && !ChaosRoll.running();
        chaosBtn.active = host;
        startBtn.active = open;
        modeBtn.setMessage(Component.literal("Режим: " + (s.mode == RunState.Mode.SEPARATE_WORLDS
            ? "отдельные миры (один seed)" : "мир хоста (все заходят к нему)")));
        chaosBtn.setMessage(Component.literal("Случайное усложнение: " + (s.chaos ? "ВКЛ" : "выкл")));
        startBtn.setMessage(Component.literal(s.launched ? "Игра запущена" :
            host ? "Старт (создать мир)" : "Ждём старт от хоста…"));

        super.extractRenderState(g, mx, my, delta);

        int cx = width / 2;
        Gfx.centered(g, "Лобби" + (host ? " (вы хост)" : ""), cx, 8, 0xFFFFFFFF);

        // рулетка предмета
        Roulette.draw(g, cx, 26, width);
        Item item = ItemPicker.pick(s.itemSeed);
        if (Roulette.running()) Gfx.centered(g, "Крутим…", cx, 76, 0xFFFFDD55);
        else Gfx.centered(g, "Предмет: " + ItemInfo.name(item), cx, 76, 0xFF55FF55);

        // усложнение — текстом, ниже описание
        if (s.chaos) {
            int shown = ChaosRoll.update();
            boolean spin = ChaosRoll.running();
            Gfx.centered(g, "Усложнение: " + Chaos.nameOf(shown), cx, 92, spin ? 0xFFFFDD55 : 0xFFFF7777);
            Gfx.centered(g, spin ? "…" : Chaos.descOf(s.chaosMod), cx, 103, 0xFFAAAAAA);
        } else {
            Gfx.centered(g, "Усложнение: выключено", cx, 92, 0xFF888888);
        }

        Gfx.centered(g, "Игроки (" + s.players.size() + "):", cx, 119, 0xFFAAAAAA);
        int y = 130;
        for (String p : s.players) {
            Gfx.centered(g, p, cx, y, 0xFFFFFFFF);
            y += 11;
            if (y > height - 150) break;
        }
        Gfx.centered(g, "Название лобби: " + s.lobbyName, cx, height - 136, 0xFF888888);
        if (host && s.mode == RunState.Mode.HOST_WORLD)
            Gfx.centered(g, "Нужен мод e4mc (общий мир)", cx, height - 147, 0xFFFFAA55);
    }
}
