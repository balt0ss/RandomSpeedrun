package dev.friendrun;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public final class LobbyRoomScreen extends Screen {
    private final Screen parent;
    private Button modeBtn, rollBtn, startBtn;

    public LobbyRoomScreen(Screen parent) {
        super(Component.literal("FriendRun"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = width / 2, by = height - 100;
        RunState s = FriendRunClient.STATE;

        modeBtn = addRenderableWidget(Button.builder(Component.empty(), b ->
            FriendRunClient.setMode(s.mode == RunState.Mode.SEPARATE_WORLDS
                ? RunState.Mode.HOST_WORLD : RunState.Mode.SEPARATE_WORLDS))
            .bounds(cx - 100, by, 200, 20).build());

        rollBtn = addRenderableWidget(Button.builder(Component.literal("Ролл предмета"), b ->
            FriendRunClient.rollItem()).bounds(cx - 100, by + 24, 200, 20).build());

        startBtn = addRenderableWidget(Button.builder(Component.literal("Старт (создать мир)"), b ->
            FriendRunClient.launch()).bounds(cx - 100, by + 48, 200, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Выйти из лобби"), b -> {
            FriendRunClient.leave();
            Minecraft.getInstance().setScreen(parent);
        }).bounds(cx - 100, by + 72, 200, 20).build());
    }

    @Override
    public void onClose() { Minecraft.getInstance().setScreen(parent); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        RunState s = FriendRunClient.STATE;

        // лобби закрылось (хост вышел / обрыв) — вернуться в меню
        if (!FriendRunClient.inLobby()) { Minecraft.getInstance().setScreen(parent); return; }

        boolean host = s.amHost, open = host && !s.launched;
        modeBtn.active = open;
        rollBtn.active = open;
        startBtn.active = open;
        modeBtn.setMessage(Component.literal("Режим: " + (s.mode == RunState.Mode.SEPARATE_WORLDS
            ? "отдельные миры (один seed)" : "мир хоста (все заходят к нему)")));
        startBtn.setMessage(Component.literal(s.launched ? "Игра запущена" :
            host ? "Старт (создать мир)" : "Ждём старт от хоста…"));

        super.render(g, mx, my, delta);

        int cx = width / 2;
        g.drawCenteredString(font, "Лобби" + (host ? " (вы хост)" : ""), cx, 14, 0xFFFFFFFF);

        Item item = ItemPicker.pick(s.itemSeed);
        ItemStack stack = new ItemStack(item);
        g.drawCenteredString(font, "Предмет раунда:", cx, 34, 0xFFAAAAAA);
        g.renderItem(stack, cx - 8, 46);
        g.drawCenteredString(font, stack.getHoverName().getString(), cx, 66, 0xFF55FF55);

        g.drawCenteredString(font, "Игроки (" + s.players.size() + "):", cx, 88, 0xFFAAAAAA);
        int y = 100;
        for (String p : s.players) {
            g.drawCenteredString(font, p, cx, y, 0xFFFFFFFF);
            y += 11;
            if (y > height - 110) break;
        }
        g.drawCenteredString(font, "Название лобби: " + s.lobbyName, cx, height - 112, 0xFF888888);
        if (host && s.mode == RunState.Mode.HOST_WORLD)
            g.drawCenteredString(font, "Нужен мод e4mc (общий мир)", cx, height - 123, 0xFFFFAA55);
    }
}
