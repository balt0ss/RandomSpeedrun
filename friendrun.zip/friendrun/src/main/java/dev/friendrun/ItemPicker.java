package dev.friendrun;

import java.util.Comparator;
import java.util.List;
import java.util.Random;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;

/** Одинаковый seed -> одинаковый предмет у всех игроков (даже в разных мирах). */
public final class ItemPicker {
    private static final String[] BAD = {
        "spawn_egg", "command_block", "structure", "jigsaw", "debug", "barrier", "bedrock",
        "light", "knowledge_book", "petrified", "reinforced_deepslate", "end_portal",
        "spawner", "vault", "infested", "player_head", "test_", "air", "farmland",
        "chorus_plant", "frogspawn", "budding", "written_book", "dragon_egg", "elytra",
        "netherite", "enchanted_golden_apple", "heavy_core", "trial_key", "ominous",
        "nether_star", "beacon", "wither"
    };

    private static List<Item> cache;

    private ItemPicker() {}

    private static boolean allowed(Item item) {
        String id = BuiltInRegistries.ITEM.getKey(item).getPath();
        for (String bad : BAD) if (id.contains(bad)) return false;
        return true;
    }

    private static synchronized List<Item> list() {
        if (cache == null) {
            cache = BuiltInRegistries.ITEM.stream()
                .filter(ItemPicker::allowed)
                .sorted(Comparator.comparing(i -> BuiltInRegistries.ITEM.getKey(i).toString()))
                .toList();
        }
        return cache;
    }

    public static Item pick(long seed) {
        List<Item> l = list();
        return l.get(new Random(seed).nextInt(l.size()));
    }
}
