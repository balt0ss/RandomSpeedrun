package dev.friendrun;

import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;

/**
 * Выбор предмета раунда. Одинаковый seed -> одинаковый предмет у всех игроков (даже в разных мирах).
 * Шанс у всех предметов из списка одинаковый (равномерный выбор).
 */
public final class ItemPicker {
    /** Убирать самые тяжёлые предметы (эндгейм, редкий лут)? Они получаемы, но раунд может длиться часами. */
    private static final boolean EXCLUDE_VERY_HARD = false;

    /** Предметы, которые НЕЛЬЗЯ получить в выживании без команд. */
    private static final Set<String> UNOBTAINABLE = Set.of(
        "air", "bedrock", "barrier", "light", "structure_void", "structure_block", "jigsaw",
        "command_block", "chain_command_block", "repeating_command_block", "command_block_minecart",
        "debug_stick", "knowledge_book", "end_portal_frame", "farmland", "frogspawn", "budding_amethyst",
        "spawner", "trial_spawner", "vault", "reinforced_deepslate", "petrified_oak_slab", "player_head",
        "suspicious_sand", "suspicious_gravel", "tall_grass", "large_fern", "test_block", "test_instance_block");
    private static final String[] UNOBTAINABLE_PREFIX = {"infested_", "test_"};
    private static final String[] UNOBTAINABLE_SUFFIX = {"_spawn_egg"};

    /** Получаемые, но очень тяжёлые предметы. */
    private static final Set<String> VERY_HARD = Set.of(
        "dragon_egg", "dragon_head", "elytra", "beacon", "nether_star", "wither_rose",
        "enchanted_golden_apple", "heavy_core", "trial_key", "ominous_trial_key", "mace",
        "conduit", "heart_of_the_sea", "dragon_breath", "lingering_potion", "netherite_scrap",
        "netherite_ingot", "netherite_block", "disc_fragment_5", "echo_shard", "recovery_compass");
    private static final String[] VERY_HARD_PREFIX = {"netherite_", "music_disc_"};
    private static final String[] VERY_HARD_SUFFIX = {"_smithing_template", "shulker_box"};

    private static List<Item> cache;

    private ItemPicker() {}

    private static boolean allowed(Item item) {
        var key = BuiltInRegistries.ITEM.getKey(item);
        if (!key.getNamespace().equals("minecraft")) return false;   // предметы других модов не берём
        String id = key.getPath();

        if (UNOBTAINABLE.contains(id)) return false;
        for (String p : UNOBTAINABLE_PREFIX) if (id.startsWith(p)) return false;
        for (String s : UNOBTAINABLE_SUFFIX) if (id.endsWith(s)) return false;

        if (EXCLUDE_VERY_HARD) {
            if (VERY_HARD.contains(id)) return false;
            for (String p : VERY_HARD_PREFIX) if (id.startsWith(p)) return false;
            for (String s : VERY_HARD_SUFFIX) if (id.endsWith(s)) return false;
        }
        return true;
    }

    private static synchronized List<Item> list() {
        if (cache == null) {
            cache = BuiltInRegistries.ITEM.stream()
                .filter(ItemPicker::allowed)
                .sorted(Comparator.comparing(i -> BuiltInRegistries.ITEM.getKey(i).toString()))
                .toList();
            FriendRunClient.LOG.info("FRun: в пуле предметов {} шт.", cache.size());
        }
        return cache;
    }

    public static Item random(Random r) {
        List<Item> l = list();
        return l.get(r.nextInt(l.size()));
    }

    public static Item pick(long seed) {
        List<Item> l = list();
        return l.get(new Random(seed).nextInt(l.size()));
    }
}
