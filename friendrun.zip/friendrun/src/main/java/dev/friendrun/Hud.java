package dev.friendrun;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.DeltaTracker;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;

public final class Hud {
    private Hud() {}

    public static void register() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
            Identifier.fromNamespaceAndPath("friendrun", "hud"), Hud::render);
    }

    /** Панель итога: кто победил, за какое время (10 секунд после конца раунда). */
    private static void drawResult(GuiGraphicsExtractor g, Minecraft mc, RunState s) {
        if (s.resultUntilNanos == 0 || System.nanoTime() - s.resultUntilNanos >= 0) return;
        int w = Math.min(260, Gfx.guiWidth(g) - 20), h = 64;
        int cx = Gfx.guiWidth(g) / 2, top = Gfx.guiHeight(g) / 5;
        int x1 = cx - w / 2;
        Gfx.rect(g, x1 - 2, top - 2, x1 + w + 2, top + h + 2, 0xFFFFD700);
        Gfx.rect(g, x1, top, x1 + w, top + h, 0xEE101010);
        Gfx.centered(g, "ЗАБЕГ ЗАВЕРШЁН", cx, top + 6, 0xFFFFD700);
        Gfx.centered(g, "Победитель: " + s.resultName, cx, top + 20, 0xFFFFFFFF);
        Gfx.centered(g, "Время: " + RunState.formatTime(s.resultMs), cx, top + 32, 0xFF55FF55);
        Gfx.centered(g, s.resultItem.isEmpty() ? "" : "Предмет: " + s.resultItem, cx, top + 44, 0xFFAAAAAA);
    }

    private static void render(GuiGraphicsExtractor g, DeltaTracker tick) {
        Minecraft mc = Minecraft.getInstance();
        RunState s = FriendRunClient.STATE;
        if (!FriendRunClient.inLobby() || mc.player == null) return;

        int x = 6, y = 6;
        drawResult(g, mc, s);
        if (s.phase == RunState.Phase.IDLE) {
            if (s.launched) {
                Gfx.text(g, s.myReady ? "Ожидаем остальных…" : "Напишите /go когда готовы", x, y, 0xFFFFDD55);
                Gfx.text(g, "Игроки: " + s.playersLine(), x, y + 11, 0xFFFFFFFF);
            }
            return;
        }
        if (s.target == null) return;

        ItemStack icon = ItemInfo.stack(s.target);
        if (icon != null) Gfx.item(g, icon, x, y);
        Gfx.text(g, ItemInfo.name(s.target), x + 20, y + 4, 0xFFFFFFFF);

        if (s.roundMod >= 0) Gfx.text(g, "Усложнение: " + Chaos.nameOf(s.roundMod), x, y + 33, 0xFFFF7777);

        if (s.phase == RunState.Phase.COUNTDOWN) {
            long left = Math.max(0, (s.countdownEndNanos - System.nanoTime()) / 1_000_000L);
            Gfx.text(g, "Старт через " + (left / 1000 + 1), x, y + 22, 0xFFFFDD55);
        } else {
            Gfx.text(g, RunState.formatTime(s.elapsedMs()), x, y + 22, 0xFF55FF55);
        }
    }
}
