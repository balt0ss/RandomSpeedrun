package dev.friendrun;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.DeltaTracker;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;

public final class Hud {
    private Hud() {}

    public static void register() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
            Identifier.fromNamespaceAndPath("friendrun", "hud"), Hud::render);
    }

    private static void render(GuiGraphicsExtractor g, DeltaTracker tick) {
        Minecraft mc = Minecraft.getInstance();
        RunState s = FriendRunClient.STATE;
        if (!FriendRunClient.inLobby() || mc.player == null) return;

        int x = 6, y = 6;
        if (s.phase == RunState.Phase.IDLE) {
            if (s.launched) {
                Gfx.text(g, s.myReady ? "Ожидаем остальных…" : "Напишите /go когда готовы", x, y, 0xFFFFDD55);
                Gfx.text(g, "Игроки: " + String.join(", ", s.players), x, y + 11, 0xFFFFFFFF);
            }
            return;
        }
        if (s.target == null) return;

        ItemStack icon = new ItemStack(s.target);
        Gfx.item(g, icon, x, y);
        Gfx.text(g, icon.getHoverName().getString(), x + 20, y + 4, 0xFFFFFFFF);

        if (s.phase == RunState.Phase.COUNTDOWN) {
            long left = Math.max(0, (s.countdownEndNanos - System.nanoTime()) / 1_000_000L);
            Gfx.text(g, "Старт через " + (left / 1000 + 1), x, y + 22, 0xFFFFDD55);
        } else {
            Gfx.text(g, RunState.formatTime(s.elapsedMs()), x, y + 22, 0xFF55FF55);
        }
    }
}
