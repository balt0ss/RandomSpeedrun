package dev.friendrun;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;

public final class Hud {
    private Hud() {}

    public static void register() {
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("friendrun", "hud"), (g, tickCounter) -> render(g));
    }

    private static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        RunState s = FriendRunClient.STATE;
        if (mc.options.hideGui || !FriendRunClient.inLobby() || mc.player == null) return;

        int x = 6, y = 6;
        if (s.phase == RunState.Phase.IDLE) {
            if (s.launched) {
                g.drawString(mc.font, s.myReady ? "Ожидаем остальных…" : "Напишите /go когда готовы", x, y, 0xFFFFDD55, true);
                g.drawString(mc.font, "Игроки: " + String.join(", ", s.players), x, y + 11, 0xFFFFFFFF, true);
            }
            return;
        }
        if (s.target == null) return;

        ItemStack icon = new ItemStack(s.target);
        g.renderItem(icon, x, y);
        g.drawString(mc.font, icon.getHoverName().getString(), x + 20, y + 4, 0xFFFFFFFF, true);

        if (s.phase == RunState.Phase.COUNTDOWN) {
            long left = Math.max(0, (s.countdownEndNanos - System.nanoTime()) / 1_000_000L);
            g.drawString(mc.font, "Старт через " + (left / 1000 + 1), x, y + 22, 0xFFFFDD55, true);
        } else {
            g.drawString(mc.font, RunState.formatTime(s.elapsedMs()), x, y + 22, 0xFF55FF55, true);
        }
    }
}
