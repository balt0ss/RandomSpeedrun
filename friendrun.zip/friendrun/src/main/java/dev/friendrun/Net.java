package dev.friendrun;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;

/** Сетевые мелочи: локальный адрес устройства и определение Android. */
public final class Net {
    private Net() {}

    public static boolean isAndroid() {
        return System.getProperty("java.runtime.name", "").toLowerCase().contains("android");
    }

    private static final java.util.regex.Pattern VIRTUAL = java.util.regex.Pattern.compile(
        "(?i)docker|veth|vmware|vmnet|virtualbox|vbox|vethernet|hyper-v|wsl|tun|tap|utun|tailscale|zerotier|hamachi|radmin|bridge|br-|vpn|loopback");

    /** Локальный IPv4 физического адаптера (192.168.x.x и т.п.) или null; виртуальные адаптеры (VPN, Docker, WSL) пропускаются. */
    public static String localIPv4() {
        String fallback = null;
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                boolean virtual = ni.isVirtual() || VIRTUAL.matcher(ni.getName() + " " + ni.getDisplayName()).find();
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!(a instanceof Inet4Address) || !a.isSiteLocalAddress()) continue;
                    if (!virtual) return a.getHostAddress();
                    if (fallback == null) fallback = a.getHostAddress();
                }
            }
        } catch (Exception ignored) {}
        return fallback;
    }

    /** Совпадают ли первые три числа адресов (одна домашняя сеть). */
    public static boolean sameSubnet(String ipA, String ipB) {
        if (ipA == null || ipB == null) return false;
        String[] a = ipA.split("\\.");
        String[] b = ipB.split("\\.");
        if (a.length != 4 || b.length != 4) return false;
        return a[0].equals(b[0]) && a[1].equals(b[1]) && a[2].equals(b[2]);
    }
}
