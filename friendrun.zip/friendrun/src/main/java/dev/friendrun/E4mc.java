package dev.friendrun;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class E4mc {
    private static final Pattern P = Pattern.compile("([A-Za-z0-9-]+(?:\\.[A-Za-z0-9-]+)*\\.e4mc\\.link)");
    private E4mc() {}

    /** Вызывается из миксина на каждое сообщение чата. */
    public static void scan(String text) {
        if (text == null) return;
        Matcher m = P.matcher(text);
        if (m.find()) FriendRunClient.onDomain(m.group(1));
    }
}
