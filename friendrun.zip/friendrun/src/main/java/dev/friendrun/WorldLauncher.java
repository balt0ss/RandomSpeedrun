package dev.friendrun;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.util.HttpUtil;
import net.minecraft.world.Difficulty;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.LevelSettings;
import net.minecraft.world.level.WorldDataConfiguration;
import net.minecraft.world.level.gamerules.GameRules;
import net.minecraft.world.level.levelgen.WorldOptions;
import net.minecraft.world.level.levelgen.presets.WorldPresets;

/**
 * ЕДИНСТВЕННОЕ место с версионно-зависимыми вызовами создания мира/подключения.
 * Если 26.3 поменял сигнатуры (LevelSettings, GameRules, createFreshLevel, startConnecting) — правьте здесь.
 */
public final class WorldLauncher {
    private WorldLauncher() {}

    public static void createWorld(long seed) {
        Minecraft mc = Minecraft.getInstance();
        String name = "FriendRun-" + (System.currentTimeMillis() / 1000);
        WorldDataConfiguration cfg = WorldDataConfiguration.DEFAULT;
        LevelSettings settings = new LevelSettings(
            name, GameType.SURVIVAL, false, Difficulty.NORMAL, false,
            new GameRules(cfg.enabledFeatures()), cfg);
        mc.createWorldOpenFlows().createFreshLevel(
            name, settings, new WorldOptions(seed, true, false),
            WorldPresets::createNormalWorldDimensions, mc.screen);
    }

    /** Открывает мир для LAN на свободном порту (e4mc перехватывает это и поднимает туннель). */
    public static boolean publish() {
        var srv = Minecraft.getInstance().getSingleplayerServer();
        return srv != null && srv.publishServer(GameType.SURVIVAL, false, HttpUtil.getAvailablePort());
    }

    /** Подключается к адресу (домен e4mc, порт по умолчанию). */
    public static void joinServer(String addr) {
        Minecraft mc = Minecraft.getInstance();
        ConnectScreen.startConnecting(mc.screen, mc, ServerAddress.parseString(addr),
            new ServerData("FriendRun", addr, ServerData.Type.OTHER), false, null);
    }
}
