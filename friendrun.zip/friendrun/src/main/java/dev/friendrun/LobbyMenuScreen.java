package dev.friendrun;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class LobbyMenuScreen extends Screen {
    private final Screen parent;
    private EditBox lobbyName, dbUrl;
    private String status = "";

    public LobbyMenuScreen(Screen parent) {
        super(Component.literal("FriendRun"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = width / 2, y = height / 2 - 60;

        lobbyName = new EditBox(font, cx - 100, y, 200, 20, Component.literal("Название"));
        lobbyName.setHint(Component.literal("Название лобби"));
        lobbyName.setMaxLength(24);
        lobbyName.setValue(Config.lastLobby);
        addRenderableWidget(lobbyName);

        addRenderableWidget(Button.builder(Component.literal("Создать лобби"), b -> {
            status = "Создаём…";
            FriendRunClient.createLobby(dbUrl.getValue(), lobbyName.getValue().trim(), this::afterConnect);
        }).bounds(cx - 100, y + 26, 98, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Войти"), b -> {
            status = "Подключаемся…";
            FriendRunClient.joinLobby(dbUrl.getValue(), lobbyName.getValue().trim(), this::afterConnect);
        }).bounds(cx + 2, y + 26, 98, 20).build());

        dbUrl = new EditBox(font, cx - 100, y + 70, 200, 20, Component.literal("URL"));
        dbUrl.setHint(Component.literal("URL базы Firebase (один раз)"));
        dbUrl.setMaxLength(200);
        dbUrl.setValue(Config.databaseUrl);
        addRenderableWidget(dbUrl);

        addRenderableWidget(Button.builder(Component.literal("Назад"), b -> onClose())
            .bounds(cx - 100, y + 120, 200, 20).build());
    }

    private void afterConnect(String err) {
        if (err != null) status = "Ошибка: " + err;
        else Mc.setScreen(new LobbyRoomScreen(parent));
    }

    @Override
    public void onClose() { Mc.setScreen(parent); }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        super.extractRenderState(g, mx, my, delta);
        int cx = width / 2, y = height / 2 - 60;
        Gfx.centered(g, "FriendRun — лобби по названию", cx, y - 20, 0xFFFFFFFF);
        Gfx.centered(g, "Настройка базы (одинаковая у всех друзей):", cx, y + 58, 0xFF888888);
        Gfx.centered(g, status, cx, y + 100, 0xFFFFDD55);
    }
}
