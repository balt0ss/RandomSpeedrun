package dev.friendrun;

import java.io.IOException;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Главное окно мода: список открытых лобби (клик = войти) + создание своего. */
public final class LobbyMenuScreen extends Screen {
    private static final int ROWS = 5;

    private final Screen parent;
    private EditBox lobbyName, dbUrl;
    private final Button[] rows = new Button[ROWS];
    private final String[] rowNames = new String[ROWS];
    private String status = "";
    private String listStatus = "Загрузка…";
    private long lastFetch = 0;
    private boolean fetching = false;

    public LobbyMenuScreen(Screen parent) {
        super(Component.literal("FriendRun"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = width / 2;

        lobbyName = new EditBox(font, cx - 130, 34, 190, 20, Component.literal("Название"));
        lobbyName.setHint(Component.literal("Название нового лобби"));
        lobbyName.setMaxLength(24);
        lobbyName.setValue(Config.lastLobby);
        addRenderableWidget(lobbyName);

        addRenderableWidget(Button.builder(Component.literal("Создать"), b -> {
            status = "Создаём…";
            FriendRunClient.createLobby(dbUrl.getValue(), lobbyName.getValue().trim(), this::afterConnect);
        }).bounds(cx + 64, 34, 66, 20).build());

        for (int i = 0; i < ROWS; i++) {
            final int idx = i;
            rows[i] = Button.builder(Component.empty(), b -> {
                if (rowNames[idx] == null) return;
                status = "Подключаемся…";
                FriendRunClient.joinLobby(dbUrl.getValue(), rowNames[idx], this::afterConnect);
            }).bounds(cx - 130, 84 + i * 22, 260, 20).build();
            rows[i].visible = false;
            addRenderableWidget(rows[i]);
        }

        addRenderableWidget(Button.builder(Component.literal("Обновить"), b -> fetch())
            .bounds(cx - 130, height - 52, 128, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Назад"), b -> onClose())
            .bounds(cx + 2, height - 52, 128, 20).build());

        dbUrl = new EditBox(font, cx - 130, height - 26, 260, 20, Component.literal("URL"));
        dbUrl.setHint(Component.literal("URL базы Firebase (один раз)"));
        dbUrl.setMaxLength(200);
        dbUrl.setValue(Config.databaseUrl);
        addRenderableWidget(dbUrl);

        fetch();
    }

    private void fetch() {
        String url = dbUrl == null ? Config.databaseUrl : dbUrl.getValue();
        lastFetch = System.currentTimeMillis();
        if (url.isBlank()) { listStatus = "Укажите URL базы внизу"; showEntries(List.of()); return; }
        if (fetching) return;
        fetching = true;
        Thread t = new Thread(() -> {
            List<Lobby.Entry> res = null;
            String err = null;
            try { res = Lobby.list(url); } catch (IOException e) { err = e.getMessage(); }
            List<Lobby.Entry> fr = res; String fe = err;
            Minecraft.getInstance().execute(() -> {
                fetching = false;
                if (fe != null) { listStatus = "Ошибка: " + fe; showEntries(List.of()); }
                else { listStatus = fr.isEmpty() ? "Открытых лобби нет — создайте своё" : "Нажмите на лобби, чтобы войти"; showEntries(fr); }
            });
        }, "FriendRun-List");
        t.setDaemon(true);
        t.start();
    }

    private void showEntries(List<Lobby.Entry> list) {
        for (int i = 0; i < ROWS; i++) {
            if (i < list.size()) {
                Lobby.Entry e = list.get(i);
                rowNames[i] = e.name();
                rows[i].visible = true;
                rows[i].active = !e.launched();
                rows[i].setMessage(Component.literal(e.name() + " — " + e.host() + "  (" + e.players() + " игр., "
                    + (e.mode() == 1 ? "общий мир" : "отдельные миры") + ")" + (e.launched() ? " [игра идёт]" : "")));
            } else {
                rowNames[i] = null;
                rows[i].visible = false;
            }
        }
    }

    private void afterConnect(String err) {
        if (err != null) status = "Ошибка: " + err;
        else Mc.setScreen(new LobbyRoomScreen(parent));
    }

    @Override
    public void onClose() { Mc.setScreen(parent); }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        if (!fetching && System.currentTimeMillis() - lastFetch > 3000) fetch();
        super.extractRenderState(g, mx, my, delta);
        int cx = width / 2;
        Gfx.centered(g, "FriendRun", cx, 14, 0xFFFFFFFF);
        Gfx.centered(g, "Открытые лобби:", cx, 68, 0xFFAAAAAA);
        Gfx.centered(g, listStatus, cx, 84 + ROWS * 22 + 4, 0xFF888888);
        Gfx.centered(g, status, cx, 84 + ROWS * 22 + 18, 0xFFFFDD55);
    }
}
