package dev.friendrun;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.item.Item;

/** Состояние лобби и забега на клиенте. Пишется только из главного потока клиента. */
public final class RunState {
    public enum Phase { IDLE, COUNTDOWN, RUNNING, WAITING_RESULT }
    public enum Mode { SEPARATE_WORLDS, HOST_WORLD }

    // лобби
    public Mode mode = Mode.SEPARATE_WORLDS;
    public long itemSeed;
    public int chaosMod;               // выпавшее в лобби усложнение (индекс)
    public boolean chaos;              // включено «случайное усложнение»
    public int roundMod = -1;          // номер усложнения текущего раунда
    public boolean launched;           // хост нажал «Старт» -> миры создаются / созданы
    public boolean amHost;
    public String lobbyName = "";
    public long roundId;
    public final List<String> players = new ArrayList<>();

    // забег
    public Phase phase = Phase.IDLE;
    public Item target;
    public long countdownEndNanos;
    public long startNanos;
    public boolean myReady;

    // итог последнего раунда (для панели на экране)
    public String resultName = "", resultItem = "";
    public long resultMs;
    public long resultUntilNanos;

    public void resetRound() {
        phase = Phase.IDLE;
        target = null;
        myReady = false;
        roundMod = -1;
    }

    public void resetAll() {
        resetRound();
        players.clear();
        launched = false;
        amHost = false;
        chaos = false;
        resultUntilNanos = 0;
        mode = Mode.SEPARATE_WORLDS;
        lobbyName = "";
        roundId = 0;
    }

    public long elapsedMs() { return (System.nanoTime() - startNanos) / 1_000_000L; }

    public static String formatTime(long ms) {
        long m = ms / 60000, s = (ms / 1000) % 60, r = ms % 1000;
        return String.format("%02d:%02d.%03d", m, s, r);
    }
}
