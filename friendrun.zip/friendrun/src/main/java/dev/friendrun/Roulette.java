package dev.friendrun;

import java.util.Random;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * Рулетка предмета как кейс в КС: лента карточек прокручивается с замедлением и останавливается на выпавшем предмете.
 * Лента строится из seed, поэтому у всех игроков выглядит одинаково.
 */
public final class Roulette {
    public static final long DURATION_MS = 5000;
    private static final int N = 50, WIN = 42, CARD = 72, PITCH = 76, H = 42;
    private static final int[] PALETTE = {0xFF3B4A6B, 0xFF4B3B6B, 0xFF6B3B5A, 0xFF6B4A3B, 0xFF3B6B55, 0xFF5A5A5A};

    private static Item[] strip;
    private static int jitter;
    private static boolean animating;
    private static long startNanos;
    private static int lastIdx = -1;

    private Roulette() {}

    public static boolean running() { return animating; }

    public static void setFinal(long seed) { build(seed); animating = false; }

    public static void start(long seed, long elapsedMs) {
        build(seed);
        animating = true;
        lastIdx = -1;
        startNanos = System.nanoTime() - elapsedMs * 1_000_000L;
    }

    private static void build(long seed) {
        Random r = new Random(seed * 31 + 7);
        strip = new Item[N];
        for (int i = 0; i < N; i++) strip[i] = ItemPicker.random(r);
        strip[WIN] = ItemPicker.pick(seed);
        jitter = r.nextInt(CARD / 2) - CARD / 4;
    }

    /** Рисует ленту; y — верх карточек. */
    public static void draw(GuiGraphicsExtractor g, int cx, int y, int maxWidth) {
        if (strip == null) return;
        int boxW = Math.min(320, maxWidth - 20);
        int x1 = cx - boxW / 2, x2 = cx + boxW / 2;

        double target = WIN * PITCH + jitter;
        double scroll = target;
        if (animating) {
            double p = (System.nanoTime() - startNanos) / 1_000_000.0 / DURATION_MS;
            if (p >= 1) {
                animating = false;
                Snd.play(Snd.ITEM_DROP, 1.0f, 1.0f);   // звук выпадения
            } else {
                double e = 1 - Math.pow(1 - Math.max(0, p), 3);   // плавное замедление
                scroll = e * target;
                int idx = (int) Math.floor((scroll + PITCH / 2.0) / PITCH);   // карточка под указателем
                if (idx != lastIdx) {
                    lastIdx = idx;
                    Snd.play(Snd.TICK, 1.1f, 0.7f);   // щелчок на каждой карточке
                }
            }
        }

        Gfx.rect(g, x1 - 2, y - 2, x2 + 2, y + H + 2, 0xFF1A1A1A);
        boolean clipped = Gfx.pushClip(g, x1, y - 2, x2, y + H + 2);

        for (int i = 0; i < N; i++) {
            int left = (int) Math.round(cx - CARD / 2.0 + i * PITCH - scroll);
            int right = left + CARD;
            if (right < x1 || left > x2) continue;
            if (!clipped && (left < x1 || right > x2)) continue;   // без обрезки рисуем только целые карточки

            Item it = strip[i];
            String name = ItemInfo.name(it);
            int base = PALETTE[Math.abs(name.hashCode()) % PALETTE.length];
            Gfx.rect(g, left, y, right, y + H, base);
            Gfx.rect(g, left, y + H - 3, right, y + H, 0xFF000000 | ((base >> 1) & 0x7F7F7F));

            ItemStack st = ItemInfo.stack(it);
            if (st != null) {
                Gfx.item(g, st, left + CARD / 2 - 8, y + 4);
                Gfx.fitted(g, name, left + CARD / 2, y + 25, CARD - 4, 0xFFFFFFFF);
            } else if (Gfx.itemTexture(g, it, left + CARD / 2 - 10, y + 3, 20)) {
                Gfx.fitted(g, name, left + CARD / 2, y + 28, CARD - 4, 0xFFFFFFFF);
            } else {
                Gfx.fitted(g, name, left + CARD / 2, y + H / 2 - 4, CARD - 4, 0xFFFFFFFF);
            }

            if (!animating && i == WIN) {   // подсветка выпавшей карточки
                int gold = 0xFFFFD700;
                Gfx.rect(g, left, y, right, y + 2, gold);
                Gfx.rect(g, left, y + H - 2, right, y + H, gold);
                Gfx.rect(g, left, y, left + 2, y + H, gold);
                Gfx.rect(g, right - 2, y, right, y + H, gold);
            }
        }
        if (clipped) Gfx.popClip(g);

        // указатель в центре
        Gfx.rect(g, cx - 1, y - 7, cx + 1, y + H + 7, 0xFFFFD700);
    }
}
