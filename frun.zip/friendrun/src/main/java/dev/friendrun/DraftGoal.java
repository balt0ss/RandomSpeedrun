package dev.friendrun;

import java.util.Locale;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

/** Typed goal stored in the shared Draft board. IDs are stable Firebase-safe strings. */
public record DraftGoal(Type type, String id) {
    public enum Type { ITEM, QUEST, ADVANCEMENT }

    public static DraftGoal parse(String raw) {
        if (raw == null) return null;
        int split = raw.indexOf(':');
        if (split <= 0 || split == raw.length() - 1) return null;
        try {
            Type type = Type.valueOf(raw.substring(0, split).toUpperCase(Locale.ROOT));
            String id = raw.substring(split + 1);
            if (type == Type.ITEM && ItemPicker.byId(id) == null) return null;
            if (type == Type.QUEST && !Quest.isKnown(id)) return null;
            if (type == Type.ADVANCEMENT && !Advancement.isKnown(id)) return null;
            return new DraftGoal(type, id);
        } catch (IllegalArgumentException ignored) { return null; }
    }

    public String encode() { return type.name().toLowerCase(Locale.ROOT) + ":" + id; }

    public String displayName() {
        return switch (type) {
            case ITEM -> {
                Item item = ItemPicker.byId(id);
                yield item == null ? id : ItemInfo.name(item);
            }
            case QUEST -> Quest.name(id);
            case ADVANCEMENT -> Advancement.name(id);
        };
    }

    public Item icon() {
        return switch (type) {
            case ITEM -> ItemPicker.byId(id);
            case QUEST -> Items.COMPASS;
            case ADVANCEMENT -> Items.KNOWLEDGE_BOOK;
        };
    }

    /** Numeric progress snapshot used to detect progress made during this round. */
    public int progressValue(net.minecraft.client.Minecraft mc) {
        if (mc == null || mc.player == null) return 0;
        return switch (type) {
            case ITEM -> {
                Item item = ItemPicker.byId(id);
                yield item == null ? 0 : Inv.count(mc.player, item);
            }
            case QUEST -> switch (id) {
                case "enter_nether" -> mc.player.level().dimension() == net.minecraft.world.level.Level.NETHER ? 1 : 0;
                case "enter_end" -> mc.player.level().dimension() == net.minecraft.world.level.Level.END ? 1 : 0;
                default -> 0;
            };
            case ADVANCEMENT -> {
                var connection = mc.getConnection();
                if (connection == null) yield 0;
                var holder = connection.getAdvancements().get(
                    net.minecraft.resources.Identifier.fromNamespaceAndPath("minecraft", id));
                var progress = holder == null ? null : connection.getAdvancements().progress().get(holder);
                yield progress != null && progress.isDone() ? 1 : 0;
            }
        };
    }

    /** Small, explicit quest catalogue; each entry has a distinct measurable condition. */
    public static final class Quest {
        private static final String[] IDS = {"enter_nether", "enter_end"};
        public static boolean isKnown(String id) { for (String value : IDS) if (value.equals(id)) return true; return false; }
        public static String name(String id) {
            return switch (id) {
                case "enter_nether" -> "Попасть в Незер";
                case "enter_end" -> "Попасть в Энд";
                default -> id;
            };
        }
        public static String[] ids() { return IDS.clone(); }
    }

    /** Real vanilla advancement IDs (not custom reward labels). */
    public static final class Advancement {
        private static final String[] IDS = {
            "story/mine_stone", "story/upgrade_tools", "story/smelt_iron", "story/obtain_armor",
            "story/iron_tools", "story/deflect_arrow", "story/form_obsidian", "story/mine_diamond",
            "story/enter_the_nether", "story/shiny_gear", "nether/return_to_sender", "nether/find_bastion",
            "nether/obtain_ancient_debris", "nether/uneasy_alliance", "end/enter_end_gateway",
            "adventure/kill_a_mob", "adventure/sleep_in_bed", "husbandry/breed_an_animal"
        };
        public static boolean isKnown(String id) { for (String value : IDS) if (value.equals(id)) return true; return false; }
        public static String name(String id) {
            String path = id.substring(id.lastIndexOf('/') + 1).replace('_', ' ');
            return "Достижение: " + Character.toUpperCase(path.charAt(0)) + path.substring(1);
        }
        public static String[] ids() { return IDS.clone(); }
    }
}
