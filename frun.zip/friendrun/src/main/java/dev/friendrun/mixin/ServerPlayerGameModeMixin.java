package dev.friendrun.mixin;

import dev.friendrun.FriendRunClient;
import dev.friendrun.RunState;
import net.minecraft.server.level.ServerPlayerGameMode;
import net.minecraft.world.level.GameType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Prevents Creative mode while a FriendRun lobby is active on the integrated server.
 * This is enforced server-side, so commands and the F3+F4 game-mode switch cannot bypass it.
 */
@Mixin(ServerPlayerGameMode.class)
public abstract class ServerPlayerGameModeMixin {
    @Inject(method = "changeGameModeForPlayer(Lnet/minecraft/world/level/GameType;)Z",
            at = @At("HEAD"), cancellable = true)
    private void friendrun$denyCreativeDuringRun(GameType requested, CallbackInfoReturnable<Boolean> cir) {
        if (requested == GameType.CREATIVE && FriendRunClient.inLobby()) {
            cir.setReturnValue(false);
        }
    }

    /** Corrects a player who was already Creative when the lobby was opened. */
    @Inject(method = "tick()V", at = @At("HEAD"))
    private void friendrun$correctExistingCreative(CallbackInfo ci) {
        if (!FriendRunClient.inLobby()) return;

        ServerPlayerGameMode self = (ServerPlayerGameMode) (Object) this;
        if (self.getGameModeForPlayer() != GameType.CREATIVE) return;

        RunState.Phase phase = FriendRunClient.STATE.phase;
        GameType enforced = (phase == RunState.Phase.COUNTDOWN)
                ? GameType.ADVENTURE : GameType.SURVIVAL;
        self.changeGameModeForPlayer(enforced);
    }
}
