package dev.friendrun;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;

/** Экран фазы драфта: на каждом ходе игрок выбирает одну из двух целей. */
public final class DraftScreen extends Screen {
    private Ui.R leftRect, rightRect, panel;
    private Button leftButton, rightButton;

    public DraftScreen() {
        super(Component.literal("FriendRun — драфт целей"));
    }

    private Button make(Ui.R r, Runnable action) {
        Button b = addRenderableWidget(Button.builder(Component.empty(), ignored -> action.run())
            .bounds(r.x(), r.y(), r.w(), r.h()).build());
        Ui.invisible(b);
        return b;
    }

    @Override
    protected void init() {
        int pw = Math.min(width - 20, 560);
        int ph = Math.min(224, height - 20);
        int px = (width - pw) / 2, py = (height - ph) / 2;
        panel = new Ui.R(px, py, pw, ph);
        int gap = 12, bw = (pw - 36) / 2;
        leftRect = new Ui.R(px + 8, py + 70, bw, 112);
        rightRect = new Ui.R(px + 20 + bw, py + 70, bw, 112);
        leftButton = make(leftRect, () -> FriendRunClient.chooseDraft(0));
        rightButton = make(rightRect, () -> FriendRunClient.chooseDraft(1));
    }

    @Override
    public void onClose() {
        // While drafting, the tick handler will reopen this screen if the user closes it.
        Mc.setScreen(null);
    }

    private void drawOption(GuiGraphicsExtractor g, Ui.R r, String id, boolean hover, boolean enabled, int index) {
        Ui.button(g, r, hover, enabled, enabled ? Ui.Kind.GREEN : Ui.Kind.NORMAL);
        Item item = ItemPicker.byId(id);
        if (item == null) {
            Gfx.centered(g, "Предмет недоступен", r.x() + r.w() / 2, r.y() + 40, Ui.MUTED);
            return;
        }
        Gfx.itemTexture(g, item, r.x() + (r.w() - 16) / 2, r.y() + 14, 16);
        Gfx.fitted(g, ItemInfo.name(item), r.x() + r.w() / 2, r.y() + 43, r.w() - 12, Ui.TEXT);
        Gfx.centered(g, "ВЫБРАТЬ " + (index + 1), r.x() + r.w() / 2, r.y() + 82, enabled ? Ui.GOLD : Ui.MUTED);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        RunState s = FriendRunClient.STATE;
        Ui.backdrop(g, width, height);
        Ui.panel(g, panel.x(), panel.y(), panel.w(), panel.h());
        Gfx.centered(g, "ДРАФТ ЦЕЛЕЙ", width / 2, panel.y() + 12, Ui.GOLD);
        Gfx.centered(g, "Выбрано " + s.draftPickCount + " / 25", width / 2, panel.y() + 31, Ui.TEXT);
        boolean myTurn = FriendRunClient.myName().equals(s.draftTurn);
        boolean canPick = myTurn && !s.draftChoiceSent && s.draftActive;
        String status = canPick ? "Твой ход — выбери один предмет" : "Выбирает: " + (s.draftTurn.isBlank() ? "ожидание" : s.draftTurn);
        Gfx.centered(g, status, width / 2, panel.y() + 48, canPick ? Ui.GREEN : Ui.MUTED);
        drawOption(g, leftRect, s.draftOfferA, leftRect.in(mx, my), canPick, 0);
        drawOption(g, rightRect, s.draftOfferB, rightRect.in(mx, my), canPick, 1);
        if (leftButton != null) leftButton.active = canPick;
        if (rightButton != null) rightButton.active = canPick;
        super.extractRenderState(g, mx, my, delta);
    }
}
