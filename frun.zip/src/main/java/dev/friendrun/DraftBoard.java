package dev.friendrun;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.*;

/**
 * Модель данных Draft. Не зависит от Minecraft UI, поэтому состояние можно сериализовать
 * в Firebase и одинаково отображать в разных мирах участников.
 */
public final class DraftBoard {
    public static final int SIZE = 5;
    public static final int CELLS = SIZE * SIZE;
    public static final long PICK_TIMEOUT_MS = 15_000L;

    public enum Category { ITEM, ADVANCEMENT, OTHER }

    public record Task(String id, String title, Category category) {
        public Task {
            id = id == null ? "" : id;
            title = title == null || title.isBlank() ? id : title;
            category = category == null ? Category.OTHER : category;
        }
        JsonObject json() {
            JsonObject o = new JsonObject();
            o.addProperty("id", id); o.addProperty("title", title);
            o.addProperty("category", category.name().toLowerCase(Locale.ROOT));
            return o;
        }
        static Task from(JsonObject o) {
            Category c;
            try { c = Category.valueOf(o.has("category") ? o.get("category").getAsString().toUpperCase(Locale.ROOT) : "OTHER"); }
            catch (RuntimeException ex) { c = Category.OTHER; }
            return new Task(o.has("id") ? o.get("id").getAsString() : "",
                o.has("title") ? o.get("title").getAsString() : "", c);
        }
    }

    public record Choice(Task left, Task right, int playerIndex, long deadlineMs) {}
    private final Task[] cells = new Task[CELLS];
    private final String[] owners = new String[CELLS];

    public synchronized boolean isFull() {
        for (Task t : cells) if (t == null) return false;
        return true;
    }
    public synchronized int filled() {
        int n = 0; for (Task t : cells) if (t != null) n++; return n;
    }
    public synchronized Task task(int cell) { return valid(cell) ? cells[cell] : null; }
    public synchronized String owner(int cell) { return valid(cell) ? owners[cell] : null; }

    /** Первый принятый захват фиксируется; повторные запросы не могут сменить владельца. */
    public synchronized boolean claim(int cell, String player) {
        if (!valid(cell) || player == null || player.isBlank() || cells[cell] == null || owners[cell] != null)
            return false;
        owners[cell] = player;
        return true;
    }
    public synchronized int score(String player) {
        int n = 0;
        if (player == null) return 0;
        for (String owner : owners) if (player.equals(owner)) n++;
        return n;
    }
    public synchronized String winner(List<String> playerOrder) {
        String best = null; int high = -1;
        if (playerOrder == null) return null;
        for (String p : playerOrder) {
            int n = score(p);
            if (n > high) { high = n; best = p; }
        }
        return best;
    }
    public synchronized boolean putTask(int cell, Task task) {
        if (!valid(cell) || task == null || cells[cell] != null) return false;
        cells[cell] = task; return true;
    }

    public synchronized JsonArray tasksJson() {
        JsonArray a = new JsonArray();
        for (Task t : cells) a.add(t == null ? com.google.gson.JsonNull.INSTANCE : t.json());
        return a;
    }
    public synchronized JsonArray ownersJson() {
        JsonArray a = new JsonArray();
        for (String owner : owners) a.add(owner == null ? com.google.gson.JsonNull.INSTANCE : new com.google.gson.JsonPrimitive(owner));
        return a;
    }
    public synchronized void load(JsonArray tasks, JsonArray ownerData) {
        Arrays.fill(cells, null); Arrays.fill(owners, null);
        if (tasks != null) for (int i=0; i<Math.min(CELLS, tasks.size()); i++) {
            if (tasks.get(i).isJsonObject()) cells[i] = Task.from(tasks.get(i).getAsJsonObject());
        }
        if (ownerData != null) for (int i=0; i<Math.min(CELLS, ownerData.size()); i++) {
            if (!ownerData.get(i).isJsonNull()) owners[i] = ownerData.get(i).getAsString();
        }
    }

    /** Базовый пул-заглушка. Позже его можно заменить каталогом предметов и advancement-целей Minecraft. */
    public static List<Task> defaultPool(Set<Category> enabled) {
        Set<Category> allowed = enabled == null ? EnumSet.allOf(Category.class) : enabled;
        List<Task> pool = new ArrayList<>();
        if (allowed.contains(Category.ITEM)) {
            String[] items = {"minecraft:oak_log|Добыть дубовое бревно", "minecraft:stone|Получить камень",
                "minecraft:iron_ingot|Получить железный слиток", "minecraft:diamond|Получить алмаз",
                "minecraft:bread|Получить хлеб", "minecraft:shield|Получить щит",
                "minecraft:water_bucket|Получить ведро воды", "minecraft:ender_pearl|Получить жемчуг Края",
                "minecraft:bow|Получить лук", "minecraft:gold_ingot|Получить золотой слиток",
                "minecraft:obsidian|Получить обсидиан", "minecraft:apple|Получить яблоко"};
            for (String line : items) {
                String[] pair = line.split("\\|", 2);
                pool.add(new Task(pair[0], pair[1], Category.ITEM));
            }
        }
        if (allowed.contains(Category.ADVANCEMENT)) {
            pool.add(new Task("adv:minecraft:story/mine_stone", "Получить достижение «Каменный век»", Category.ADVANCEMENT));
            pool.add(new Task("adv:minecraft:story/smelt_iron", "Получить достижение «Приключения»", Category.ADVANCEMENT));
            pool.add(new Task("adv:minecraft:story/upgrade_tools", "Получить достижение «Обновление»", Category.ADVANCEMENT));
            pool.add(new Task("adv:minecraft:story/enter_the_nether", "Попасть в Незер", Category.ADVANCEMENT));
        }
        if (allowed.contains(Category.OTHER)) {
            pool.add(new Task("other:visit_nether", "Посетить Незер", Category.OTHER));
            pool.add(new Task("other:reach_y100", "Подняться на высоту Y=100", Category.OTHER));
            pool.add(new Task("other:breed_animal", "Развести животных", Category.OTHER));
            pool.add(new Task("other:kill_hostile", "Убить враждебного моба", Category.OTHER));
        }
        return List.copyOf(pool);
    }

    public static Choice choices(List<Task> pool, long seed, int playerIndex, long nowMs) {
        if (pool == null || pool.isEmpty()) throw new IllegalArgumentException("Draft task pool is empty");
        Random r = new Random(seed ^ (0x9E3779B97F4A7C15L * (playerIndex + 1L)));
        Task a = pool.get(r.nextInt(pool.size()));
        Task b = a;
        if (pool.size() > 1) {
            for (int i=0; i<8 && b.id().equals(a.id()); i++) b = pool.get(r.nextInt(pool.size()));
            if (b.id().equals(a.id())) b = pool.get((pool.indexOf(a)+1)%pool.size());
        }
        return new Choice(a, b, playerIndex, nowMs + PICK_TIMEOUT_MS);
    }
    public static int nextPlayer(int current, int playerCount) {
        if (playerCount <= 0) return -1;
        return (Math.max(-1, current) + 1) % playerCount;
    }
    private static boolean valid(int cell) { return cell >= 0 && cell < CELLS; }
}
