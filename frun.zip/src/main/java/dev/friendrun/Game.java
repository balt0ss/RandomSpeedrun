package dev.friendrun;

/** Режимы FriendRun, включая запуск встроенной карты «Столбы». */
public final class Game {
    public static final int SPEEDRUN = 0, CONVEYOR = 1, CHAIN = 2, BINGO = 3, WAVES = 4, MANHUNT = 5, PILLARS = 6, DRAFT = 7, SINGLE_SPEEDRUN = 8, COUNT = 9;
    public static final long WAVES_CAP_MS = 30 * 60_000L;
    public static final long SLOT_MS = 3 * 60_000L;
    public static final long CONVEYOR_TOTAL_MS = 20 * 60_000L;
    public static final int CHAIN_LEN = 5;

    private Game() {}

    public static String name(int g) {
        return switch (g) {
            case CONVEYOR -> Tr.t("friendrun.mode.conveyor.name", "Conveyor");
            case CHAIN -> Tr.t("friendrun.mode.chain.name", "Item Chain");
            case BINGO -> Tr.t("friendrun.mode.bingo.name", "Bingo");
            case WAVES -> Tr.t("friendrun.mode.waves.name", "Mob Waves");
            case MANHUNT -> Tr.t("friendrun.mode.manhunt.name", "Manhunt");
            case PILLARS -> Tr.t("friendrun.mode.pillars.name", "Pillars");
            case DRAFT -> Tr.t("friendrun.mode.draft.name", "Draft");
            case SINGLE_SPEEDRUN -> Tr.t("friendrun.mode.solo.name", "Solo Speedrun");
            default -> Tr.t("friendrun.mode.speedrun.name", "Speedrun");
        };
    }

    public static String desc(int g) {
        return switch (g) {
            case CONVEYOR -> Tr.t("friendrun.mode.conveyor.desc", "A new target every 3 minutes. Play for 20 minutes.");
            case CHAIN -> Tr.t("friendrun.mode.chain.desc", "Collect 5 targets in the required order.");
            case BINGO -> Tr.t("friendrun.mode.bingo.desc", "Complete the card objective before your opponents.");
            case WAVES -> Tr.t("friendrun.mode.waves.desc", "Survive mob waves and earn points.");
            case MANHUNT -> Tr.t("friendrun.mode.manhunt.desc", "Runners escape while hunters track them down.");
            case PILLARS -> Tr.t("friendrun.mode.pillars.desc", "Battle on the preset Pillars map.");
            case DRAFT -> Tr.t("friendrun.mode.draft.desc", "Pick goals in turns and claim more cells.");
            case SINGLE_SPEEDRUN -> Tr.t("friendrun.mode.solo.desc", "A solo run to the End credits. Personal record, no rating.");
            default -> Tr.t("friendrun.mode.speedrun.desc", "Be the first player to obtain the target item.");
        };
    }
}
