package dev.friendrun;

/** Режимы FriendRun, включая запуск встроенной карты «Столбы». */
public final class Game {
    public static final int SPEEDRUN = 0, CONVEYOR = 1, CHAIN = 2, BINGO = 3, WAVES = 4, MANHUNT = 5, PILLARS = 6, DRAFT = 7, DRAFT_PLUS = 8, SINGLE_SPEEDRUN = 9, COUNT = 10;   // id режимов = индекс в Ranking.MODE_KEYS (SINGLE_SPEEDRUN — без рейтинга, всегда последний)
    public static final long WAVES_CAP_MS = 30 * 60_000L;       // волны: максимум 30 минут
    public static final long SLOT_MS = 3 * 60_000L;              // конвейер: смена предмета каждые 3 минуты
    public static final long CONVEYOR_TOTAL_MS = 20 * 60_000L;   // конвейер: длительность раунда
    public static final int CHAIN_LEN = 5;                       // цепочка: сколько предметов

    private Game() {}

    private static String key(int g) {
        return switch (g) {
            case CONVEYOR -> "conveyor"; case CHAIN -> "chain"; case BINGO -> "bingo"; case WAVES -> "waves";
            case MANHUNT -> "manhunt"; case PILLARS -> "pillars"; case DRAFT -> "draft"; case DRAFT_PLUS -> "draftplus";
            case SINGLE_SPEEDRUN -> "single"; default -> "speedrun";
        };
    }

    /** Название режима (lang: friendrun.mode.<режим>.name). */
    public static String name(int g) {
        String def = switch (g) {
            case CONVEYOR -> "Тайм-атака"; case CHAIN -> "Эстафета"; case BINGO -> "Бинго"; case WAVES -> "Орда";
            case MANHUNT -> "Манхант"; case PILLARS -> "Столбы"; case DRAFT -> "Драфт"; case DRAFT_PLUS -> "Драфт+";
            case SINGLE_SPEEDRUN -> "Any%"; default -> "Спринт";
        };
        return Tr.t("friendrun.mode." + key(g) + ".name", def);
    }

    /** Короткое описание правил (lang: friendrun.mode.<режим>.desc). */
    public static String desc(int g) {
        String def = switch (g) {
            case CONVEYOR -> "Бой с часами: цель меняется каждые несколько минут. Сдайте больше всех за раунд.";
            case CHAIN -> "Забег по этапам: добывайте предметы строго по порядку. Кто первым пройдёт все этапы — победил.";
            case BINGO -> "Карточка с предметами: первым закройте линию (или всю карточку).";
            case WAVES -> "Режим выживания: отбивайтесь от волн мобов. Побеждает тот, кто набрал больше очков.";
            case MANHUNT -> "Беглецы выживают до конца времени, охотники ловят их. Нужен общий мир.";
            case PILLARS -> "Готовая карта «Столбики»: рейтинговый раунд на встроенной арене. Нужен общий мир.";
            case DRAFT -> "По очереди выбирайте цели на общую карточку и захватывайте их. Побеждает тот, кто взял больше половины клеток.";
            case DRAFT_PLUS -> "Драфт с бан-пиком как в киберспорте: баны целей, роли и хаос-событие. В рейтинге учитывается личный вклад.";
            case SINGLE_SPEEDRUN -> "Классический спидран Any%: пройдите Minecraft до титров как можно быстрее. Без рейтинга — личный рекорд.";
            default -> "Короткий забег: всем выпадает один предмет — кто первым его добудет, тот и победил.";
        };
        return Tr.t("friendrun.mode." + key(g) + ".desc", def);
    }
}
