package dev.friendrun;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/** Общие константы и безопасные операции для режима Draft 5×5. */
public final class Draft {
    public static final int SIZE = 5;
    public static final int CELLS = SIZE * SIZE;
    public static final long PICK_TIMEOUT_MS = 15_000L;
    public static final long NO_TIMER = 0L;

    public enum Category { ITEM, ADVANCEMENT, OTHER }
    public record Task(String id, String title, Category category) {
        public Task {
            if (id == null || id.isBlank()) throw new IllegalArgumentException("Task id is empty");
            if (title == null || title.isBlank()) title = id;
            if (category == null) category = Category.OTHER;
        }
    }
    public record Choice(Task left, Task right) {
        public Choice {
            if (left == null || right == null || left.id().equals(right.id()))
                throw new IllegalArgumentException("Draft needs two different tasks");
        }
    }

    private Draft() {}

    /** Stable pseudo-random pair: every client can display the same pair for a given seed and turn. */
    public static Choice choices(List<Task> pool, long seed, int turn) {
        if (pool == null || pool.size() < 2) throw new IllegalArgumentException("Draft pool needs at least two tasks");
        Random random = new Random(seed ^ (0x9E3779B97F4A7C15L * (turn + 1L)));
        int a = random.nextInt(pool.size());
        int b = random.nextInt(pool.size() - 1);
        if (b >= a) b++;
        return new Choice(pool.get(a), pool.get(b));
    }

    /** Claims a cell only if it is still free. The first successful claim wins. */
    public static synchronized boolean claim(String[] owners, int cell, String player) {
        if (owners == null || owners.length != CELLS || cell < 0 || cell >= CELLS || player == null || player.isBlank()) return false;
        if (owners[cell] != null && !owners[cell].isBlank()) return false;
        owners[cell] = player;
        return true;
    }

    public static int claimed(String[] owners) {
        if (owners == null) return 0;
        int count = 0;
        for (String owner : owners) if (owner != null && !owner.isBlank()) count++;
        return count;
    }

    public static boolean full(String[] owners) { return claimed(owners) == CELLS; }

    public static int score(String[] owners, String player) {
        if (owners == null || player == null) return 0;
        int count = 0;
        for (String owner : owners) if (player.equals(owner)) count++;
        return count;
    }

    public static List<String> encodeOwners(String[] owners) {
        if (owners == null || owners.length != CELLS) return new ArrayList<>(Arrays.asList(new String[CELLS]));
        return new ArrayList<>(Arrays.asList(owners.clone()));
    }
}
