package dev.friendrun;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Отдельный экран выбора режима с краткими объяснениями. */
public final class GameModeScreen extends Screen {
    private final Screen parent;
    private final List<Ui.R> cards = new ArrayList<>();
    private final List<Button> cardButtons = new ArrayList<>();
    private Button back;
    private Ui.R backRect;
    private int cols, cardW, cardH, gap, startX, startY;
    /** Режимы в сетке: Драфт+ — не отдельная карточка, а вариация Драфта (переключатель в его настройках). */
    private final List<Integer> modes = new ArrayList<>();

    public GameModeScreen(Screen parent) {
        super(Component.literal("FriendRun — выбор режима"));
        this.parent = parent;
    }

    private Button make(Ui.R r, Runnable action) {
        Button b = addRenderableWidget(Button.builder(Component.empty(), x -> action.run())
            .bounds(r.x(), r.y(), r.w(), r.h()).build());
        Ui.invisible(b);
        return b;
    }

    @Override
    protected void init() {
        cards.clear();
        cardButtons.clear();
        modes.clear();
        for (int m = 0; m < Game.COUNT; m++) if (m != Game.DRAFT_PLUS) modes.add(m);
        int margin = 12;
        cols = width >= 650 ? 3 : 2;
        gap = 8;
        int areaW = Math.min(width - margin * 2, 760);
        cardW = (areaW - gap * (cols - 1)) / cols;
        int rows = (modes.size() + cols - 1) / cols;
        int availableCardH = Math.max(height < 340 ? 44 : 52, (height - 76 - (rows - 1) * gap) / rows);
        cardH = Math.min(height < 400 ? 76 : 88, availableCardH);
        int gridH = rows * cardH + (rows - 1) * gap;
        startX = (width - (cardW * cols + gap * (cols - 1))) / 2;
        startY = Math.max(34, Math.min(56, (height - gridH - 30) / 2));

        for (int i = 0; i < modes.size(); i++) {
            final int mode = modes.get(i);
            int col = i % cols, row = i / cols;
            Ui.R r = new Ui.R(startX + col * (cardW + gap), startY + row * (cardH + gap), cardW, cardH);
            cards.add(r);
            cardButtons.add(make(r, () -> {
                RunState s = FriendRunClient.STATE;
                if (!s.amHost || s.phase != RunState.Phase.IDLE) return;
                // Драфт+ остаётся вариацией: повторный выбор «Драфта» не сбрасывает её.
                if (!(mode == Game.DRAFT && s.gameMode == Game.DRAFT_PLUS)) FriendRunClient.setGameMode(mode);
                Mc.setScreen(parent);
            }));
        }

        backRect = new Ui.R(width / 2 - 54, height - 30, 108, 20);
        back = make(backRect, () -> Mc.setScreen(parent));
    }

    @Override
    public void onClose() { Mc.setScreen(parent); }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        RunState s = FriendRunClient.STATE;
        boolean canChoose = s.amHost && s.phase == RunState.Phase.IDLE;

        // Единый фон и заголовок
        Ui.backdrop(g, width, height);
        int panelW = Math.min(width - 12, 790);
        int panelX = (width - panelW) / 2;
        Ui.panel(g, panelX, 8, panelW, height - 16);
        Icons.draw(g, Icons.DICE, panelX + 14, 20, 2, Ui.GOLD);
        Ui.bold(g, Tr.t("friendrun.ui.pick_mode", "Выбор режима"), panelX + 36, 18, Ui.GOLD);
        Gfx.text(g, canChoose ? Tr.t("friendrun.ui.pick_mode_hint", "Выбери, во что будете играть") : Tr.t("friendrun.ui.pick_mode_host", "Режим может менять только хост до начала раунда"),
            panelX + 14, 34, Ui.MUTED);

        for (int i = 0; i < cards.size(); i++) {
            Ui.R r = cards.get(i);
            int mode = modes.get(i);
            boolean selected = s.gameMode == mode || (mode == Game.DRAFT && s.gameMode == Game.DRAFT_PLUS);
            boolean hover = r.in(mx, my);
            boolean active = canChoose;
            Ui.Kind kind = selected ? Ui.Kind.GREEN : Ui.Kind.NORMAL;
            Ui.button(g, r, hover, active, kind);
            if (selected) {
                Gfx.rect(g, r.x() + 1, r.y() + 1, r.x() + 4, r.y() + r.h() - 1, Ui.GREEN);
                Icons.draw(g, Icons.CHECK, r.x() + r.w() - 15, r.y() + 8, 1, Ui.GREEN);
            }
            int titleColor = active ? Ui.TEXT : Ui.MUTED;
            int iconColor = selected ? Ui.GREEN : (active ? Ui.GOLD : 0xFF626D7D);
            Icons.draw(g, Icons.mode(mode), r.x() + 10, r.y() + 10, 2, iconColor);
            Gfx.text(g, Game.name(mode) + (mode == Game.DRAFT && s.gameMode == Game.DRAFT_PLUS ? " +" : ""), r.x() + 30, r.y() + 10, selected ? Ui.GREEN : titleColor);
            String descText = Game.desc(mode == Game.DRAFT && s.gameMode == Game.DRAFT_PLUS ? Game.DRAFT_PLUS : mode);
            // Слева оставляем место под иконку; на высоких карточках описание переносится на вторую строку.
            int maxW = r.w() - 40;
            int maxLines = r.h() >= 66 ? 2 : 1;
            List<String> lines = new ArrayList<>();
            StringBuilder cur = new StringBuilder();
            for (String word : descText.split(" ")) {
                String t = cur.length() == 0 ? word : cur + " " + word;
                if (Ui.w(t) > maxW && cur.length() > 0) { lines.add(cur.toString()); cur = new StringBuilder(word); }
                else cur = new StringBuilder(t);
            }
            if (cur.length() > 0) lines.add(cur.toString());
            if (lines.size() > maxLines) {
                lines = new ArrayList<>(lines.subList(0, maxLines));
                lines.set(maxLines - 1, Ui.trunc(lines.get(maxLines - 1) + "…", maxW));
            }
            for (int li = 0; li < lines.size(); li++)
                Gfx.text(g, Ui.trunc(lines.get(li), maxW), r.x() + 30, r.y() + 27 + li * 11, active ? Ui.MUTED : 0xFF626D7D);
            if (selected) Gfx.text(g, Tr.t("friendrun.ui.current", "ТЕКУЩИЙ"), r.x() + 10, r.y() + r.h() - 16, Ui.GREEN);
            else if (active) Gfx.text(g, Tr.t("friendrun.ui.click_to_pick", "Нажми для выбора"), r.x() + 10, r.y() + r.h() - 16, Ui.MUTED);
        }

        super.extractRenderState(g, mx, my, delta);
        Ui.button(g, backRect, backRect.in(mx, my), true, Ui.Kind.NORMAL);
        Gfx.centered(g, Tr.t("friendrun.ui.back", "Назад"), backRect.x() + backRect.w() / 2, backRect.cy() - 4, Ui.TEXT);
        for (int i = 0; i < cardButtons.size(); i++) cardButtons.get(i).active = canChoose;
    }
}
