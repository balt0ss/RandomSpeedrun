package dev.friendrun;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * «Вид лобби»: личная кастомизация интерфейса (см. {@link LobbyStyle}). Изменения применяются сразу
 * и сохраняются в config/friendrun.json; другие игроки их не видят.
 */
public final class LobbyStyleScreen extends Screen {
    private static final int ROW_H = 22;

    /** Строка списка: заголовок раздела (act == null), переключатель (toggle) или выбор из вариантов. */
    private record Row(String label, String value, boolean toggle, boolean on, int swatch, Runnable act) {}

    private final Screen parent;
    private int px, py, pw, ph, ix, iw, listY, rows, scroll;
    private Ui.R rDone, rReset;
    private Button bDone, bReset;
    private Button[] slots;

    public LobbyStyleScreen(Screen parent) {
        super(Component.literal("FRun: вид лобби"));
        this.parent = parent;
    }

    private Button make(Ui.R r, Runnable action) {
        Button b = addRenderableWidget(Button.builder(Component.empty(), x -> action.run())
            .bounds(r.x(), r.y(), r.w(), r.h()).build());
        Ui.invisible(b);
        return b;
    }

    private static void changed() { Config.save(); }

    @Override
    protected void init() {
        pw = Math.min(width - 16, 440);
        ph = Math.min(height - 8, 330);
        px = (width - pw) / 2;
        py = Math.max(4, (height - ph) / 2);
        ix = px + 10;
        iw = pw - 20;
        listY = py + 40;
        rows = Math.max(3, (py + ph - 8 - listY) / ROW_H);
        rDone = new Ui.R(px + pw - 10 - 64, py + 6, 64, 18);
        rReset = new Ui.R(rDone.x() - 4 - 78, py + 6, 78, 18);
        bDone = make(rDone, this::onClose);
        bReset = make(rReset, () -> { LobbyStyle.reset(); changed(); });
        slots = new Button[rows];
        for (int i = 0; i < rows; i++) {
            final int slot = i;
            slots[i] = make(new Ui.R(ix, listY + i * ROW_H, iw - 16, ROW_H - 2), () -> click(slot));
        }
    }

    private List<Row> list() {
        List<Row> l = new ArrayList<>();
        l.add(new Row("Цвет акцента", LobbyStyle.ACCENT_NAMES[LobbyStyle.accent], false, false, LobbyStyle.accentColor(),
            () -> { LobbyStyle.cycleAccent(); changed(); }));
        l.add(new Row("Прозрачность панелей", LobbyStyle.PANEL_NAMES[LobbyStyle.panel], false, false, 0,
            () -> { LobbyStyle.cyclePanel(); changed(); }));
        l.add(new Row("Настройки справа, игроки слева", "", true, LobbyStyle.swapPanels, 0,
            () -> { LobbyStyle.swapPanels = !LobbyStyle.swapPanels; changed(); }));
        l.add(new Row("Узкая панель комнаты", "", true, LobbyStyle.compact, 0,
            () -> { LobbyStyle.compact = !LobbyStyle.compact; changed(); }));
        l.add(new Row("Рейтинг у игроков в комнате", "", true, LobbyStyle.showRating, 0,
            () -> { LobbyStyle.showRating = !LobbyStyle.showRating; changed(); }));
        l.add(new Row("Головы игроков", "", true, LobbyStyle.showHeads, 0,
            () -> { LobbyStyle.showHeads = !LobbyStyle.showHeads; changed(); }));
        l.add(new Row("Анимации появления", "", true, LobbyStyle.animations, 0,
            () -> { LobbyStyle.animations = !LobbyStyle.animations; changed(); }));
        l.add(new Row("Строка в списке лобби:", "", false, false, 0, null));
        l.add(new Row("Хост", "", true, LobbyStyle.colHost, 0, () -> { LobbyStyle.colHost = !LobbyStyle.colHost; changed(); }));
        l.add(new Row("Режим игры", "", true, LobbyStyle.colMode, 0, () -> { LobbyStyle.colMode = !LobbyStyle.colMode; changed(); }));
        l.add(new Row("Усложнение", "", true, LobbyStyle.colChaos, 0, () -> { LobbyStyle.colChaos = !LobbyStyle.colChaos; changed(); }));
        l.add(new Row("Игроки и готовность", "", true, LobbyStyle.colPlayers, 0, () -> { LobbyStyle.colPlayers = !LobbyStyle.colPlayers; changed(); }));
        l.add(new Row("Тип мира", "", true, LobbyStyle.colWorld, 0, () -> { LobbyStyle.colWorld = !LobbyStyle.colWorld; changed(); }));
        return l;
    }

    private void click(int slot) {
        List<Row> l = list();
        int idx = scroll + slot;
        if (idx >= 0 && idx < l.size() && l.get(idx).act() != null) l.get(idx).act().run();
    }

    private void scrollBy(int d) {
        scroll = Math.max(0, Math.min(Math.max(0, list().size() - rows), scroll + d));
    }

    /** Колесо мыши (без @Override, как в остальных экранах мода). */
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        scrollBy(scrollY > 0 ? -1 : 1);
        return true;
    }

    @Override
    public void onClose() { Mc.setScreen(parent); }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        LobbyStyle.begin();
        try {
            render(g, mx, my, delta);
        } finally {
            LobbyStyle.end();
        }
    }

    private void render(GuiGraphicsExtractor g, int mx, int my, float delta) {
        List<Row> l = list();
        scrollBy(0);
        for (int i = 0; i < slots.length; i++) slots[i].visible = scroll + i < l.size() && l.get(scroll + i).act() != null;

        Ui.backdrop(g, width, height);
        Ui.panel(g, px, py, pw, ph);
        Ui.bold(g, "ВИД ЛОББИ", px + 12, py + 11, Ui.GOLD);
        Gfx.text(g, Ui.trunc("Только для вас: другие игроки видят своё оформление", iw), ix, py + 28, Ui.MUTED);

        super.extractRenderState(g, mx, my, delta);

        Ui.button(g, rDone, rDone.in(mx, my), true, Ui.Kind.GOLD);
        Gfx.centered(g, "Готово", rDone.x() + rDone.w() / 2, rDone.y() + 5, 0xFF1A1200);
        Ui.button(g, rReset, rReset.in(mx, my), true, Ui.Kind.NORMAL);
        Gfx.centered(g, "Сбросить", rReset.x() + rReset.w() / 2, rReset.y() + 5, Ui.TEXT);

        for (int i = 0; i < slots.length; i++) {
            int idx = scroll + i;
            if (idx >= l.size()) break;
            Row r = l.get(idx);
            Ui.R rr = new Ui.R(ix, listY + i * ROW_H, iw - 16, ROW_H - 2);
            if (r.act() == null) {
                Gfx.text(g, r.label(), rr.x() + 2, rr.cy() - 4, Ui.GOLD);
                continue;
            }
            Ui.button(g, rr, rr.in(mx, my), true, r.toggle() && r.on() ? Ui.Kind.GREEN : Ui.Kind.NORMAL);
            Gfx.text(g, Ui.trunc(r.label(), rr.w() - 90), rr.x() + 8, rr.cy() - 4, Ui.TEXT);
            if (r.toggle()) {
                int tx = rr.x() + rr.w() - 30;
                Gfx.rect(g, tx, rr.cy() - 5, tx + 22, rr.cy() + 5, r.on() ? Ui.GREEN : 0xFF3A4658);
                int kx = r.on() ? tx + 13 : tx + 1;
                Gfx.rect(g, kx, rr.cy() - 4, kx + 8, rr.cy() + 4, 0xFFFFFFFF);
            } else {
                Ui.right(g, r.value(), rr.x() + rr.w() - (r.swatch() != 0 ? 26 : 10), rr.cy() - 4, Ui.TEXT);
                if (r.swatch() != 0) Gfx.rect(g, rr.x() + rr.w() - 20, rr.cy() - 5, rr.x() + rr.w() - 8, rr.cy() + 5, r.swatch());
            }
        }
        Ui.scrollbar(g, px + pw - 16, listY, rows * ROW_H - 2, scroll, l.size(), rows);
    }
}
