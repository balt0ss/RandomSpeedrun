package dev.friendrun;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Interactive Draft 5x5 screen: choose a task during the draft, then claim free cells. */
public final class DraftScreen extends Screen {
    private final Screen parent;
    private final List<Button> cellButtons = new ArrayList<>();
    private Button leftChoice, rightChoice, close;
    private Ui.R[] cells = new Ui.R[25];
    private Ui.R leftRect, rightRect, closeRect;
    private int panelX, panelW, panelY, panelH, boardX, boardY, cellSize, cellGap;

    public DraftScreen(Screen parent) {
        super(Component.literal("FriendRun — Draft 5×5"));
        this.parent = parent;
    }

    private Button button(Ui.R r, Runnable action) {
        Button b = addRenderableWidget(Button.builder(Component.empty(), ignored -> action.run())
            .bounds(r.x(), r.y(), r.w(), r.h()).build());
        Ui.invisible(b);
        return b;
    }

    @Override protected void init() {
        cellButtons.clear();
        panelW = Math.min(Math.max(280, width - 12), 780);
        panelX = (width - panelW) / 2;
        panelY = 8;
        panelH = Math.max(100, height - 16);
        int margin = 12;
        int usable = Math.max(250, panelW - margin * 2);
        int availableByWidth = (usable - 4 * 4) / 5;
        int topArea = Math.max(70, Math.min(100, height / 6));
        int bottomArea = Math.max(28, Math.min(44, height / 12));
        int availableByHeight = Math.max(24, (height - topArea - bottomArea - 34) / 5);
        cellSize = Math.max(24, Math.min(64, Math.min(availableByWidth, availableByHeight)));
        cellGap = 4;
        int boardW = cellSize * 5 + cellGap * 4;
        boardX = (width - boardW) / 2;
        boardY = Math.max(74, topArea + 24);
        if (boardY + boardW > height - bottomArea - 8) boardY = Math.max(58, height - bottomArea - boardW - 8);

        int choiceGap = 8;
        int choiceW = Math.min((panelW - 32 - choiceGap) / 2, 300);
        int choiceY = Math.max(30, boardY - 58);
        int choiceH = Math.max(38, Math.min(48, boardY - 14));
        int choiceX = width / 2 - choiceW - choiceGap / 2;
        leftRect = new Ui.R(choiceX, choiceY, choiceW, choiceH);
        rightRect = new Ui.R(width / 2 + choiceGap / 2, choiceY, choiceW, choiceH);
        leftChoice = button(leftRect, () -> FriendRunClient.submitDraftChoice(0));
        rightChoice = button(rightRect, () -> FriendRunClient.submitDraftChoice(1));

        for (int i = 0; i < 25; i++) {
            final int cell = i;
            int x = boardX + (i % 5) * (cellSize + cellGap);
            int y = boardY + (i / 5) * (cellSize + cellGap);
            cells[i] = new Ui.R(x, y, cellSize, cellSize);
            cellButtons.add(button(cells[i], () -> FriendRunClient.submitDraftClaim(cell)));
        }
        closeRect = new Ui.R(width / 2 - 48, height - 22, 96, 16);
        close = button(closeRect, () -> Mc.setScreen(parent));
    }

    @Override public void onClose() { Mc.setScreen(parent); }

    private static String category(String raw) {
        return switch (raw == null ? "" : raw.toLowerCase(java.util.Locale.ROOT)) {
            case "item" -> "ПРЕДМЕТ";
            case "advancement" -> "ДОСТИЖЕНИЕ";
            default -> "ЗАДАНИЕ";
        };
    }

    private static String shorten(String text, int maxWidth) {
        if (text == null) return "";
        String s = text;
        while (!s.isEmpty() && Ui.w(s) > maxWidth) {
            if (s.length() <= 2) return "…";
            s = s.substring(0, s.length() - 2) + "…";
        }
        return s;
    }

    private static void inventoryPanel(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        // Vanilla inventory-like raised gray panel with dark outline and pale bevel.
        Gfx.rect(g, x - 3, y - 3, x + w + 3, y + h + 3, 0xFF080808);
        Gfx.rect(g, x - 1, y - 1, x + w + 1, y + h + 1, 0xFF373737);
        Gfx.rect(g, x, y, x + w, y + h, 0xFFC6C6C6);
        Gfx.rect(g, x + 2, y + 2, x + w - 2, y + 3, 0xFFFFFFFF);
        Gfx.rect(g, x + 2, y + 2, x + 3, y + h - 2, 0xFFFFFFFF);
        Gfx.rect(g, x + 2, y + h - 3, x + w - 2, y + h - 2, 0xFF555555);
        Gfx.rect(g, x + w - 3, y + 2, x + w - 2, y + h - 2, 0xFF555555);
    }

    private static void slot(GuiGraphicsExtractor g, Ui.R r, boolean hover, boolean active, boolean occupied) {
        int edge = occupied ? 0xFF4C9C50 : (hover && active ? 0xFF3F9D9A : 0xFF555555);
        Gfx.rect(g, r.x(), r.y(), r.x() + r.w(), r.y() + r.h(), edge);
        Gfx.rect(g, r.x() + 1, r.y() + 1, r.x() + r.w() - 1, r.y() + r.h() - 1, 0xFFC6C6C6);
        Gfx.rect(g, r.x() + 3, r.y() + 3, r.x() + r.w() - 3, r.y() + r.h() - 3, occupied ? 0xFF7F9F7F : 0xFF8B8B8B);
        Gfx.rect(g, r.x() + 3, r.y() + 3, r.x() + r.w() - 3, r.y() + 4, 0xFFAAAAAA);
        Gfx.rect(g, r.x() + 3, r.y() + 3, r.x() + 4, r.y() + r.h() - 3, 0xFFAAAAAA);
        if (hover && active) Gfx.rect(g, r.x() + 3, r.y() + 3, r.x() + r.w() - 3, r.y() + 5, 0xFF4EC4BE);
    }

    @Override public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        RunState s = FriendRunClient.STATE;
        // Keep the world visible, as in a vanilla inventory, with two light-gray inventory panels.
        Gfx.rect(g, 0, 0, width, height, 0x65000000);
        int boardW = cellSize * 5 + cellGap * 4;
        int boardH = boardW;
        int topPanelX = Math.max(4, panelX + 8);
        int topPanelW = Math.max(160, panelW - 16);
        int topPanelY = Math.max(5, leftRect.y() - 8);
        int topPanelH = leftRect.h() + 16;
        inventoryPanel(g, topPanelX, topPanelY, topPanelW, topPanelH);
        inventoryPanel(g, boardX - 10, boardY - 10, boardW + 20, boardH + 20);

        boolean drafting = "drafting".equals(s.draftPhase);
        boolean running = "running".equals(s.draftPhase);
        boolean myTurn = drafting && s.draftCurrentPlayer.equals(FriendRunClient.myName());
        String status;
        if (drafting) {
            long remaining = Math.max(0, s.draftTurnDeadline - System.currentTimeMillis());
            status = s.draftCurrentPlayer + " · " + ((remaining + 999) / 1000) + "с";
        } else if (running) {
            status = "Выбери свободную клетку";
            if (s.draftTimeMin > 0 && s.draftGameStartedAt > 0) {
                long left = Math.max(0, s.draftGameStartedAt + s.draftTimeMin * 60_000L - System.currentTimeMillis());
                status += " · " + ((left + 999) / 1000) + "с";
            }
        } else status = "Ожидание Draft…";
        Gfx.centered(g, status, width / 2, Math.max(7, topPanelY - 12), 0xFFFFFFFF);

        for (int i = 0; i < 2; i++) {
            Ui.R r = i == 0 ? leftRect : rightRect;
            boolean available = myTurn && s.draftOptionTitles[i] != null;
            slot(g, r, r.in(mx, my), available, false);
            String title = s.draftOptionTitles[i] == null ? "Ожидание…" : s.draftOptionTitles[i];
            String cat = category(s.draftOptionCategories[i]);
            Gfx.centered(g, shorten(title, r.w() - 12), r.cx(), r.y() + Math.max(4, r.h() / 2 - 5), 0xFFFFFFFF);
            if (r.h() >= 42) Gfx.centered(g, cat, r.cx(), r.y() + r.h() - 13, 0xFFE0E0E0);
            Button b = i == 0 ? leftChoice : rightChoice;
            b.active = available;
            b.visible = true;
        }
        if (drafting && !myTurn) Gfx.centered(g, "Выбор делает " + s.draftCurrentPlayer, width / 2, topPanelY + topPanelH + 2, 0xFFFFFFFF);
        else if (drafting && myTurn) Gfx.centered(g, "Выбери один из двух вариантов", width / 2, topPanelY + topPanelH + 2, 0xFFFFFFFF);

        for (int i = 0; i < 25; i++) {
            Ui.R r = cells[i];
            String title = s.draftTaskTitles[i];
            String owner = s.draftOwners[i];
            boolean occupied = owner != null && !owner.isBlank();
            boolean selectable = running && !occupied && title != null;
            slot(g, r, r.in(mx, my), selectable, occupied);
            if (title == null) {
                Gfx.centered(g, "", r.cx(), r.cy() - 4, 0xFFFFFFFF);
            } else {
                String label = shorten(title, r.w() - 8);
                Gfx.centered(g, label, r.cx(), r.y() + Math.max(4, r.h() / 2 - 4), 0xFFFFFFFF);
                if (occupied && r.h() >= 36) Gfx.centered(g, shorten(owner, r.w() - 6), r.cx(), r.y() + r.h() - 12, 0xFFFFE76D);
            }
            cellButtons.get(i).active = selectable;
            cellButtons.get(i).visible = true;
        }

        int picked = 0;
        for (String owner : s.draftOwners) if (owner != null && !owner.isBlank()) picked++;
        String footer = "Pick " + (drafting ? Math.min(25, s.draftTurn + 1) : picked) + " / 25";
        Gfx.centered(g, footer, width / 2, Math.min(height - 26, boardY + boardH + 18), 0xFFE0E0E0);

        java.util.List<java.util.Map.Entry<String, Integer>> scores = new ArrayList<>(s.draftScores.entrySet());
        scores.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
        if (running && !scores.isEmpty() && boardY + boardH + 32 < height - 24) {
            StringBuilder line = new StringBuilder();
            for (int i = 0; i < Math.min(scores.size(), 3); i++) {
                if (i > 0) line.append("  ·  ");
                line.append(scores.get(i).getKey()).append(" ").append(scores.get(i).getValue());
            }
            Gfx.centered(g, shorten(line.toString(), panelW - 24), width / 2, boardY + boardH + 30, 0xFFFFFFFF);
        }
        Ui.button(g, closeRect, closeRect.in(mx, my), true, Ui.Kind.NORMAL);
        Gfx.centered(g, "Закрыть", closeRect.cx(), closeRect.cy() - 4, 0xFFE0E0E0);
        super.extractRenderState(g, mx, my, delta);
    }

}
