package dev.friendrun;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Interactive Draft 5x5 screen: choose a task during the draft, then claim free cells. */
public final class DraftScreen extends Screen {
    private final Screen parent;
    private final List<Button> cellButtons = new ArrayList<>();
    private Button leftChoice, rightChoice, close;
    private Ui.R[] cells = new Ui.R[25];
    private Ui.R leftRect, rightRect, closeRect;
    private int panelX, panelW, panelY, panelH, boardX, boardY, cellSize, cellGap;

    public DraftScreen(Screen parent) {
        super(Component.literal("FriendRun — Draft 5×5"));
        this.parent = parent;
    }

    private Button button(Ui.R r, Runnable action) {
        Button b = addRenderableWidget(Button.builder(Component.empty(), ignored -> action.run())
            .bounds(r.x(), r.y(), r.w(), r.h()).build());
        Ui.invisible(b);
        return b;
    }

    @Override protected void init() {
        cellButtons.clear();
        panelW = Math.min(Math.max(280, width - 12), 780);
        panelX = (width - panelW) / 2;
        panelY = 6;
        panelH = Math.max(100, height - 12);
        int margin = 12;
        int usable = Math.max(250, panelW - margin * 2);
        int availableByWidth = (usable - 4 * 4) / 5;
        int availableByHeight = Math.max(28, (height - 152) / 5);
        cellSize = Math.max(28, Math.min(64, Math.min(availableByWidth, availableByHeight)));
        cellGap = 4;
        int boardW = cellSize * 5 + cellGap * 4;
        boardX = (width - boardW) / 2;
        boardY = Math.min(height - boardW - 14, 124);
        if (boardY < 92) boardY = 92;

        int choiceGap = 8;
        int choiceW = Math.min((panelW - 32 - choiceGap) / 2, 300);
        int choiceX = width / 2 - choiceW - choiceGap / 2;
        leftRect = new Ui.R(choiceX, 55, choiceW, 48);
        rightRect = new Ui.R(width / 2 + choiceGap / 2, 55, choiceW, 48);
        leftChoice = button(leftRect, () -> FriendRunClient.submitDraftChoice(0));
        rightChoice = button(rightRect, () -> FriendRunClient.submitDraftChoice(1));

        for (int i = 0; i < 25; i++) {
            final int cell = i;
            int x = boardX + (i % 5) * (cellSize + cellGap);
            int y = boardY + (i / 5) * (cellSize + cellGap);
            cells[i] = new Ui.R(x, y, cellSize, cellSize);
            cellButtons.add(button(cells[i], () -> FriendRunClient.submitDraftClaim(cell)));
        }
        closeRect = new Ui.R(width / 2 - 48, height - 25, 96, 18);
        close = button(closeRect, () -> Mc.setScreen(parent));
    }

    @Override public void onClose() { Mc.setScreen(parent); }

    private static String category(String raw) {
        return switch (raw == null ? "" : raw.toLowerCase(java.util.Locale.ROOT)) {
            case "item" -> "ПРЕДМЕТ";
            case "advancement" -> "ДОСТИЖЕНИЕ";
            default -> "ЗАДАНИЕ";
        };
    }

    private static String shorten(String text, int maxWidth) {
        if (text == null) return "";
        String s = text;
        while (!s.isEmpty() && Ui.w(s) > maxWidth) {
            if (s.length() <= 2) return "…";
            s = s.substring(0, s.length() - 2) + "…";
        }
        return s;
    }

    @Override public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        RunState s = FriendRunClient.STATE;
        Ui.backdrop(g, width, height);
        Ui.panel(g, panelX, panelY, panelW, panelH);
        Icons.draw(g, Icons.DICE, panelX + 12, 14, 2, Ui.GOLD);
        Ui.bold(g, "Draft · поле 5×5", panelX + 34, 12, Ui.GOLD);

        boolean drafting = "drafting".equals(s.draftPhase);
        boolean running = "running".equals(s.draftPhase);
        boolean myTurn = drafting && s.draftCurrentPlayer.equals(FriendRunClient.myName());
        String status;
        if (drafting) {
            long remaining = Math.max(0, s.draftTurnDeadline - System.currentTimeMillis());
            status = "Драфт · ход " + Math.min(25, s.draftTurn + 1) + "/25 · " + s.draftCurrentPlayer
                + " · " + ((remaining + 999) / 1000) + "с";
        } else if (running) {
            status = "Игра идёт · нажми свободную клетку, чтобы занять её";
            if (s.draftTimeMin > 0 && s.draftGameStartedAt > 0) {
                long left = Math.max(0, s.draftGameStartedAt + s.draftTimeMin * 60_000L - System.currentTimeMillis());
                status += " · осталось " + ((left + 999) / 1000) + "с";
            }
        } else {
            status = "Ожидание состояния Draft от хоста";
        }
        Gfx.centered(g, status, width / 2, 34, Ui.MUTED);

        for (int i = 0; i < 2; i++) {
            Ui.R r = i == 0 ? leftRect : rightRect;
            boolean available = myTurn && s.draftOptionTitles[i] != null;
            Ui.button(g, r, r.in(mx, my), available, available ? Ui.Kind.GREEN : Ui.Kind.NORMAL);
            String title = s.draftOptionTitles[i] == null ? "Ожидание варианта…" : s.draftOptionTitles[i];
            String cat = category(s.draftOptionCategories[i]);
            Gfx.centered(g, shorten(title, r.w() - 12), r.cx(), r.y() + 14, available ? Ui.TEXT : Ui.MUTED);
            Gfx.centered(g, cat, r.cx(), r.y() + 31, available ? Ui.GREEN : Ui.MUTED);
            Button b = i == 0 ? leftChoice : rightChoice;
            b.active = available;
            b.visible = true;
        }
        if (drafting && !myTurn) Gfx.centered(g, "Выбор делает " + s.draftCurrentPlayer, width / 2, 109, Ui.ORANGE);
        else if (drafting && myTurn) Gfx.centered(g, "Выбери один из двух вариантов до конца таймера", width / 2, 109, Ui.GREEN);

        for (int i = 0; i < 25; i++) {
            Ui.R r = cells[i];
            String title = s.draftTaskTitles[i];
            String owner = s.draftOwners[i];
            boolean occupied = owner != null && !owner.isBlank();
            boolean selectable = running && !occupied && title != null;
            boolean hover = r.in(mx, my);
            Ui.Kind kind = occupied ? Ui.Kind.GREEN : Ui.Kind.NORMAL;
            Ui.button(g, r, hover, selectable, kind);
            if (title == null) {
                Gfx.centered(g, "·", r.cx(), r.cy() - 4, Ui.MUTED);
            } else {
                String label = shorten(title, r.w() - 8);
                Gfx.centered(g, label, r.cx(), r.y() + Math.max(5, r.h() / 2 - 4), occupied ? Ui.GREEN : Ui.TEXT);
                if (occupied) {
                    String own = shorten(owner, r.w() - 6);
                    Gfx.centered(g, own, r.cx(), r.y() + r.h() - 11, Ui.GOLD);
                }
            }
            cellButtons.get(i).active = selectable;
            cellButtons.get(i).visible = true;
        }

        // Compact scoreboard under the board; no bingo-line logic is used for Draft.
        int scoreY = boardY + 5 * (cellSize + cellGap) + 4;
        java.util.List<java.util.Map.Entry<String, Integer>> scores = new ArrayList<>(s.draftScores.entrySet());
        scores.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
        if (!scores.isEmpty() && scoreY < height - 30) {
            StringBuilder line = new StringBuilder("Очки: ");
            for (int i = 0; i < Math.min(scores.size(), 4); i++) {
                if (i > 0) line.append("  ·  ");
                line.append(scores.get(i).getKey()).append(" ").append(scores.get(i).getValue());
            }
            Gfx.centered(g, shorten(line.toString(), panelW - 24), width / 2, scoreY, Ui.TEXT);
        }

        Ui.button(g, closeRect, closeRect.in(mx, my), true, Ui.Kind.NORMAL);
        Gfx.centered(g, "Закрыть", closeRect.cx(), closeRect.cy() - 4, Ui.MUTED);
        super.extractRenderState(g, mx, my, delta);
    }
}
