package dev.friendrun;

import com.google.gson.JsonObject;

/**
 * Личная кастомизация интерфейса лобби (сохраняется в config/friendrun.json, видна только вам):
 * цвет акцента, прозрачность панелей, расположение колонок комнаты, что показывать в списке игроков
 * и в строке списка лобби.
 *
 * Цвета подменяются в {@link Ui} только на время отрисовки экранов лобби ({@link #begin()} / {@link #end()}),
 * остальные экраны мода остаются золотыми.
 */
public final class LobbyStyle {
    /** Цветовые темы: акцент, тёмный акцент, фон золотой кнопки, он же при наведении, блик, линия, выключенная кнопка. */
    private static final int[][] ACCENTS = {
        {0xFFFFC82E, 0xFF8A650A, 0xFFD9A31A, 0xFFF2B91E, 0xFFFFE7A1, 0xFFFFE08A, 0xFF4A3A10},   // золото
        {0xFF3DDC84, 0xFF14703E, 0xFF22B866, 0xFF2FD67B, 0xFFA8F5CB, 0xFF8CF0B8, 0xFF12402A},   // изумруд
        {0xFF4DB8FF, 0xFF1A5C8A, 0xFF2A8FD6, 0xFF3FA6F0, 0xFFB5E3FF, 0xFF9CD6FF, 0xFF133650},   // лазурь
        {0xFFFF5C93, 0xFF8A1F45, 0xFFD6336F, 0xFFF0467F, 0xFFFFB3CE, 0xFFFFA0C0, 0xFF4A1528},   // малина
        {0xFFB388FF, 0xFF5A3A9A, 0xFF8A5CE0, 0xFF9C73F2, 0xFFDCC8FF, 0xFFD0B8FF, 0xFF2E1F52},   // фиолет
    };
    public static final String[] ACCENT_NAMES = {"Золото", "Изумруд", "Лазурь", "Малина", "Фиолет"};
    private static final int[] PANEL_ALPHA = {0xF0, 0xCC, 0xA0};
    public static final String[] PANEL_NAMES = {"плотные", "мягкие", "прозрачные"};

    public static int accent = 0, panel = 0;
    /** Колонка настроек справа, список игроков слева. */
    public static boolean swapPanels = false;
    /** Более узкая комната. */
    public static boolean compact = false;
    public static boolean showRating = true, showHeads = true, animations = true;
    /** Что показывать во второй строке списка лобби. */
    public static boolean colHost = true, colMode = true, colChaos = true, colPlayers = true, colWorld = true;

    private static int depth;
    private static int[] saved;

    private LobbyStyle() {}

    public static int accentColor() { return ACCENTS[accent][0]; }

    public static void begin() {
        if (depth++ > 0) return;
        saved = new int[] {Ui.BG, Ui.GOLD, Ui.GOLD_D, Ui.GOLD_BTN, Ui.GOLD_BTN_H, Ui.GOLD_TOP, Ui.GOLD_LINE, Ui.GOLD_OFF};
        int[] a = ACCENTS[Math.floorMod(accent, ACCENTS.length)];
        Ui.BG = (PANEL_ALPHA[Math.floorMod(panel, PANEL_ALPHA.length)] << 24) | 0x101A2B;
        Ui.GOLD = a[0]; Ui.GOLD_D = a[1]; Ui.GOLD_BTN = a[2]; Ui.GOLD_BTN_H = a[3]; Ui.GOLD_TOP = a[4]; Ui.GOLD_LINE = a[5]; Ui.GOLD_OFF = a[6];
    }

    public static void end() {
        if (depth == 0 || --depth > 0 || saved == null) return;
        Ui.BG = saved[0]; Ui.GOLD = saved[1]; Ui.GOLD_D = saved[2]; Ui.GOLD_BTN = saved[3];
        Ui.GOLD_BTN_H = saved[4]; Ui.GOLD_TOP = saved[5]; Ui.GOLD_LINE = saved[6]; Ui.GOLD_OFF = saved[7];
    }

    public static void reset() {
        accent = 0; panel = 0;
        swapPanels = false; compact = false;
        showRating = showHeads = animations = true;
        colHost = colMode = colChaos = colPlayers = colWorld = true;
    }

    static void read(JsonObject o) {
        if (o.has("lsAccent")) accent = Math.floorMod(o.get("lsAccent").getAsInt(), ACCENTS.length);
        if (o.has("lsPanel")) panel = Math.floorMod(o.get("lsPanel").getAsInt(), PANEL_ALPHA.length);
        if (o.has("lsSwap")) swapPanels = o.get("lsSwap").getAsBoolean();
        if (o.has("lsCompact")) compact = o.get("lsCompact").getAsBoolean();
        if (o.has("lsRating")) showRating = o.get("lsRating").getAsBoolean();
        if (o.has("lsHeads")) showHeads = o.get("lsHeads").getAsBoolean();
        if (o.has("lsAnim")) animations = o.get("lsAnim").getAsBoolean();
        if (o.has("lsColHost")) colHost = o.get("lsColHost").getAsBoolean();
        if (o.has("lsColMode")) colMode = o.get("lsColMode").getAsBoolean();
        if (o.has("lsColChaos")) colChaos = o.get("lsColChaos").getAsBoolean();
        if (o.has("lsColPlayers")) colPlayers = o.get("lsColPlayers").getAsBoolean();
        if (o.has("lsColWorld")) colWorld = o.get("lsColWorld").getAsBoolean();
    }

    static void write(JsonObject o) {
        o.addProperty("lsAccent", accent);
        o.addProperty("lsPanel", panel);
        o.addProperty("lsSwap", swapPanels);
        o.addProperty("lsCompact", compact);
        o.addProperty("lsRating", showRating);
        o.addProperty("lsHeads", showHeads);
        o.addProperty("lsAnim", animations);
        o.addProperty("lsColHost", colHost);
        o.addProperty("lsColMode", colMode);
        o.addProperty("lsColChaos", colChaos);
        o.addProperty("lsColPlayers", colPlayers);
        o.addProperty("lsColWorld", colWorld);
    }

    public static void cycleAccent() { accent = (accent + 1) % ACCENTS.length; }
    public static void cyclePanel() { panel = (panel + 1) % PANEL_ALPHA.length; }
}
