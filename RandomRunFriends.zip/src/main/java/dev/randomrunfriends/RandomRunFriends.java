package dev.randomrunfriends;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public final class RandomRunFriends implements ModInitializer {
    private static final Random RANDOM = new Random();
    private static final List<Item> ITEM_POOL = new ArrayList<>();

    private static boolean raceActive;
    private static Item targetItem;
    private static long startTick;
    private static boolean announceWinner = true;
    private static int minimumCount = 1;

    @Override
    public void onInitialize() {
        buildItemPool();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(Commands.literal("rr")
                .then(Commands.literal("start")
                    .requires(source -> source.hasPermission(2))
                    .executes(context -> startRace(context.getSource().getServer(), context.getSource())))
                .then(Commands.literal("stop")
                    .requires(source -> source.hasPermission(2))
                    .executes(context -> stopRace(context.getSource().getServer(), context.getSource())))
                .then(Commands.literal("status")
                    .executes(context -> showStatus(context.getSource().getServer(), context.getSource())))
                .then(Commands.literal("target")
                    .executes(context -> showTarget(context.getSource())))
                .then(Commands.literal("settings")
                    .requires(source -> source.hasPermission(2))
                    .then(Commands.literal("announceWinner")
                        .then(RequiredArgumentBuilder.<CommandSourceStack, Boolean>argument("enabled", BoolArgumentType.bool())
                            .executes(context -> {
                                announceWinner = BoolArgumentType.getBool(context, "enabled");
                                context.getSource().sendSuccess(() -> Component.literal("RandomRun: announceWinner=" + announceWinner), false);
                                return 1;
                            })))
                    .then(Commands.literal("minimumCount")
                        .then(RequiredArgumentBuilder.<CommandSourceStack, Integer>argument("count", IntegerArgumentType.integer(1, 64))
                            .executes(context -> {
                                minimumCount = IntegerArgumentType.getInteger(context, "count");
                                context.getSource().sendSuccess(() -> Component.literal("RandomRun: minimumCount=" + minimumCount), false);
                                return 1;
                            })))
                ))
        );

        ServerTickEvents.END_SERVER_TICK.register(this::onServerTick);
    }

    private static void buildItemPool() {
        ITEM_POOL.clear();
        for (Item item : BuiltInRegistries.ITEM) {
            if (item == null || item == Items.AIR || item.getDefaultInstance().isEmpty()) continue;
            ITEM_POOL.add(item);
        }
    }

    private static int startRace(MinecraftServer server, CommandSourceStack source) {
        if (raceActive) {
            source.sendFailure(Component.literal("A RandomRun race is already active. Use /rr stop first."));
            return 0;
        }
        if (ITEM_POOL.isEmpty()) buildItemPool();
        if (ITEM_POOL.isEmpty()) {
            source.sendFailure(Component.literal("RandomRun: item pool is empty."));
            return 0;
        }

        targetItem = ITEM_POOL.get(RANDOM.nextInt(ITEM_POOL.size()));
        raceActive = true;
        startTick = server.getTickCount();
        server.getPlayerList().broadcastSystemMessage(
            Component.literal("[RandomRun] Race started! Target: " + itemId(targetItem)), false);
        return 1;
    }

    private static int stopRace(MinecraftServer server, CommandSourceStack source) {
        if (!raceActive) {
            source.sendFailure(Component.literal("RandomRun: no race is active."));
            return 0;
        }
        raceActive = false;
        server.getPlayerList().broadcastSystemMessage(Component.literal("[RandomRun] Race stopped."), false);
        targetItem = null;
        return 1;
    }

    private static int showStatus(MinecraftServer server, CommandSourceStack source) {
        String status = raceActive
            ? "Active — target: " + itemId(targetItem) + ", elapsed: " + ((server.getTickCount() - startTick) / 20) + "s"
            : "Idle";
        source.sendSuccess(() -> Component.literal("RandomRun: " + status), false);
        return 1;
    }

    private static int showTarget(CommandSourceStack source) {
        if (!raceActive || targetItem == null) {
            source.sendFailure(Component.literal("RandomRun: no active target."));
            return 0;
        }
        source.sendSuccess(() -> Component.literal("Target: " + itemId(targetItem)), false);
        return 1;
    }

    private void onServerTick(MinecraftServer server) {
        if (!raceActive || targetItem == null) return;

        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (hasTarget(player, targetItem, minimumCount)) {
                long elapsed = (server.getTickCount() - startTick) / 20;
                Item wonTarget = targetItem;
                raceActive = false;
                server.getPlayerList().broadcastSystemMessage(
                    Component.literal("[RandomRun] " + player.getGameProfile().getName()
                        + " wins in " + elapsed + "s! Target: " + itemId(wonTarget)), false);
                if (announceWinner) {
                    player.sendSystemMessage(Component.literal("You won! Congratulations."));
                }
                targetItem = null;
                break;
            }
        }
    }

    private static boolean hasTarget(ServerPlayer player, Item target, int count) {
        int found = 0;
        var inventory = player.getInventory();
        for (int slot = 0; slot < inventory.getContainerSize(); slot++) {
            ItemStack stack = inventory.getItem(slot);
            if (!stack.isEmpty() && stack.is(target)) {
                found += stack.getCount();
                if (found >= count) return true;
            }
        }
        return false;
    }

    private static String itemId(Item item) {
        return BuiltInRegistries.ITEM.getKey(item).toString();
    }
}
