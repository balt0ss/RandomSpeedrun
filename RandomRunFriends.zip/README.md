# RandomRun Friends

A small Fabric mod for a server-authoritative target-item race with friends.

## Commands

- `/rr start` — operator starts a race and picks a random target item.
- `/rr stop` — operator stops the current race.
- `/rr status` — displays race state and elapsed time.
- `/rr target` — displays the active target.
- `/rr settings announceWinner true|false` — operator setting.
- `/rr settings minimumCount 1..64` — required number of target items.

The server checks connected players' inventories and announces the first winner. Install the same mod on the server; clients may also install it.

## Build automatically on GitHub

The workflow at `.github/workflows/build.yml` builds the project on every push and can be run manually from the Actions tab. The resulting JAR appears under the workflow run's **Artifacts** section as `RandomRunFriends-JAR`.

**Important:** GitHub Actions does not run a workflow merely because a ZIP file containing a workflow was uploaded. Extract this project into the repository so `.github/workflows/build.yml` is a real repository file, then commit/push the extracted contents. If your repository already has a workflow specifically designed to build uploaded ZIP archives, you can adapt it to this archive.

## Status and limitations

This is an initial MVP, not a tested release. The current implementation is a simple global target race; it does not yet implement random drops, a custom HUD, teams, saved history, or reconnect persistence. A build succeeding is not proof that multiplayer behavior is bug-free; test on a separate server with two clients before using it in a real world.
